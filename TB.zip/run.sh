#!/usr/bin/env bash
# =============================================================================
# run.sh — Verilator compile + run + VCD dump
#
# Usage:
#   ./run.sh <filelist.f> <top_module> [vcd_file] [run_dir]
#
#   filelist.f : danh sách RTL + TB (Verilator -f format, mỗi dòng 1 file)
#   top_module : tên module testbench (module này phải không có port)
#   vcd_file   : tên file VCD (mặc định: <top_module>.vcd)
#   run_dir    : thư mục chạy simulation / nơi TB đọc sim_* (mặc định: thư mục filelist)
#
# Env:
#   JOBS=2          số job build
#   OPT=-O0         mức tối ưu Verilator
#   VLT_INC=...     thêm include dir (-I...)
#   VLT_ARGS=...    thêm argument Verilator (chuỗi, tách bằng dấu cách)
#
# Ghi chú:
#   - TB được bọc trong module `vcd_wrapper` để gọi $dumpfile/$dumpvars mà
#     không cần sửa TB gốc.
#   - Script cd vào run_dir trước khi chạy, nên các đường dẫn $readmemh
#     tương đối (sim_gemm_prefill/hex/...) vẫn đúng.
# =============================================================================
set -euo pipefail

usage() {
    sed -n '2,28p' "$0" | sed 's/^# \{0,1\}//'
    exit 1
}

[[ $# -ge 2 ]] || usage

FILELIST_IN=$1
TOP=$2
VCD=${3:-${TOP}.vcd}
RUN_DIR=${4:-$(cd "$(dirname "$FILELIST_IN")" && pwd)}

# Resolve filelist to an absolute path before changing directory.
FILELIST=$(cd "$(dirname "$FILELIST_IN")" && pwd)/$(basename "$FILELIST_IN")
[[ -f "$FILELIST" ]] || { echo "ERROR: filelist not found: $FILELIST" >&2; exit 1; }

mkdir -p "$RUN_DIR"
RUN_DIR=$(cd "$RUN_DIR" && pwd)
OBJ="$RUN_DIR/obj_$TOP"
WRAP="$OBJ/vcd_wrapper.sv"
mkdir -p "$OBJ"

# One-cycle name, avoid clashing with user modules.
cat > "$WRAP" <<EOF
\`timescale 1ns/1ps
module vcd_wrapper;
    $TOP u_tb();

    initial begin
        \$dumpfile("$VCD");
        \$dumpvars(0, vcd_wrapper);
    end
endmodule
EOF

VLT_INC_ARG=()
if [[ -n "${VLT_INC:-}" ]]; then
    VLT_INC_ARG=(-I"$VLT_INC")
fi

# Auto-add the directory of every source file in the filelist as an include
# directory.  This makes `include "pe_defines.svh"` work without VLT_INC.
while IFS= read -r raw; do
    line="${raw%%#*}"
    line="$(printf '%s' "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
    [[ -z "$line" ]] && continue
    [[ "$line" == -* || "$line" == +* ]] && continue

    if [[ -f "$RUN_DIR/$line" ]]; then
        src="$RUN_DIR/$line"
    elif [[ -f "$line" ]]; then
        src="$line"
    else
        continue
    fi
    dir="$(dirname "$src")"
    case " ${VLT_INC_ARG[*]:-} " in
        *" -I$dir "*) ;;
        *) VLT_INC_ARG+=(-I"$dir") ;;
    esac
done < "$FILELIST"

# shellcheck disable=SC2206
EXTRA_ARGS=(${VLT_ARGS:-})

cd "$RUN_DIR"

echo "[run.sh] filelist : $FILELIST"
echo "[run.sh] top      : $TOP"
echo "[run.sh] run_dir  : $RUN_DIR"
echo "[run.sh] vcd      : $RUN_DIR/$VCD"
echo "[run.sh] build    : $OBJ"

verilator \
    --binary \
    --timing \
    --trace \
    -j "${JOBS:-$(nproc)}" \
    --top-module vcd_wrapper \
    "${OPT:--O0}" \
    --x-assign fast \
    --x-initial fast \
    -Wno-fatal \
    -Wno-INITIALDLY \
    -Wno-LATCH \
    -Wno-WIDTH \
    -Wno-CASEINCOMPLETE \
    -Wno-UNOPTFLAT \
    -Wno-COMBDLY \
    -Wno-SELRANGE \
    -Wno-ALWCOMBORDER \
    -Wno-DECLFILENAME \
    -Wno-UNUSEDSIGNAL \
    "${VLT_INC_ARG[@]}" \
    "${EXTRA_ARGS[@]}" \
    --Mdir "$OBJ" \
    -f "$FILELIST" \
    "$WRAP" \
    2>&1 | tee "$OBJ/compile.log"

EXE="$OBJ/Vvcd_wrapper"
[[ -x "$EXE" ]] || { echo "ERROR: build failed, no $EXE" >&2; exit 1; }

echo "[run.sh] running $EXE ..."
"$EXE" 2>&1 | tee "$OBJ/run.log"
RC=${PIPESTATUS[0]}

if [[ -f "$VCD" ]]; then
    echo "[run.sh] VCD written: $RUN_DIR/$VCD ($(du -h "$VCD" | cut -f1))"
else
    echo "[run.sh] WARNING: VCD not found: $RUN_DIR/$VCD" >&2
fi

exit "$RC"
