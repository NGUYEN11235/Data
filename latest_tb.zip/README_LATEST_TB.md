# SNAX FP4 LLM Subsystem — Latest Testbenches

Package date: 2026-11-09
Layout:

```
tb/    testbenches, generators, proof scripts
sim/   golden HEX/CSV data, read by the TBs relative to the run directory
```

Pair this package with `latest_rtl.zip` (RTL package). Extract both so that
this directory and `latest_rtl_pkg/` are siblings.

## Testbenches

| TB | Purpose |
|---|---|
| `tb_snax_llm_top_flash.sv` | integrated top: host DMA preload + CSR + streamers + TCDM + core + write_out |
| `tb_snax_core_flash_system.sv` | core + 3 streamers + 19-master xbar + TCDM |
| `tb_snax_core_flash_tiling.sv` | full flash-tiling loop nest at core level |
| `tb_snax_streamer_write_out.sv` | write-out transpose, 16 tokens x 16 channels |
| `tb_snax_streamer_wt_16ch.sv` | 16-channel wt streamer FIFO-head replay |
| `tb_fixed_priority_arb.sv` | per-bank stream-over-host priority |
| `tb_snax_gemm_prefill.sv` | GEMM prefill 16x256 x 256x16 |
| `tb_snax_gemm_tiled.sv` | tiled GEMM 32x512 x 512x64 |
| `tb_snax_attention.sv` | one-query fused attention, 32 keys |
| `tb_snax_fused_attn_8x8.sv` | 8-query 8:8 FlashAttention |
| `tb_skid_buffer.sv`, `tb_slq_encoder.sv` | unit tests |

Generators: `generate_prefill_gemm_data.py`, `generate_tiled_gemm_data.py`,
`generate_attention_data.py`, `generate_fused_attn_8x8.py`,
`generate_snax_core_flash_tiling_data.py`, `generate_slq_encoder_data.py`.
Proof scripts: `prove_flashattention_tiling.py`,
`prove_full_flashattention_tiling_dv.py`.

## Run directory

Run simulations from `sim/` so the TB's relative `sim_*` paths resolve:

```bash
cd latest_tb_pkg/sim
```

Golden data included:

```
sim_attn/
sim_fused_attn_8x8/
sim_snax_core_flash/
sim_slq_encoder/
sim_gemm_prefill/
sim_gemm_tiled/
```

## Example: top-level TB with Verilator

```bash
cd latest_tb_pkg/sim
RTL_DIR=/path/to/latest_rtl_pkg/rtl/01_snax_llm_fp4_subsystem
SIMLATCH=/path/to/latest_rtl_pkg/sim/latch_array_sim.sv
TB_DIR=../tb

mapfile -t RTL < <(find "$RTL_DIR" -maxdepth 1 -name '*.sv' \
  ! -name 'latch_array.sv' | sort)

verilator --binary --timing -j2 \
  --top-module tb_snax_llm_top_flash -O0 \
  --x-assign fast --x-initial fast \
  -Wno-fatal -Wno-INITIALDLY -Wno-LATCH -Wno-WIDTH \
  -Wno-CASEINCOMPLETE -Wno-UNOPTFLAT -Wno-COMBDLY \
  -I"$RTL_DIR" \
  "${RTL[@]}" "$SIMLATCH" \
  "$TB_DIR/tb_snax_llm_top_flash.sv"

./obj_dir/Vtb_snax_llm_top_flash
```

For the other core-level TBs, replace the `--top-module` and TB file. The
`sim/latch_array_sim.sv` is simulation-only; for synthesis use the real
`rtl/.../latch_array.sv`.

## Regenerating golden data

Run generators from `tb/`; they write `../sim/sim_*` (or local
`sim_gemm_*` for the prefill/tiled generators). Example:

```bash
cd latest_tb_pkg/tb
python3 generate_attention_data.py
python3 generate_fused_attn_8x8.py
python3 generate_snax_core_flash_tiling_data.py
python3 generate_slq_encoder_data.py
```

## Verification status (with latest RTL)

| TB | Result |
|---|---|
| `tb_snax_llm_top_flash` | PASS 1024/1024 bit-exact |
| `tb_snax_core_flash_system` | PASS 1024/1024 bit-exact |
| `tb_snax_core_flash_tiling` | PASS 1024/1024 bit-exact |
| `tb_snax_streamer_write_out` | PASS 256/256 transpose |
| `tb_snax_streamer_wt_16ch` | PASS |
| `tb_fixed_priority_arb` | PASS |

The older GEMM/attention/8x8 TBs were verified earlier against the previous
RTL snapshot; re-run them against this exact RTL package before signing off.

## Notes

- TB outputs are English-only, as required for Questa/VCD logs.
- Some older TBs drive packed ports directly; if Verilator reports zero data
  from a packed array port, use a flat TB signal or a newer Verilator.
- `latch_array_sim.sv` is not part of the synthetic RTL; it only removes the
  8192-latch flattening cost in simulation.
