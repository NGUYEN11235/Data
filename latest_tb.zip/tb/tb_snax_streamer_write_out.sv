// =============================================================================
// tb_snax_streamer_write_out.sv
// Unit test for snax_streamer_write_out transpose mode.
//
// Feeds 16 tokens x 16 channels of unique FP16 patterns, runs one transpose
// pass, then checks that channel c is stored in bank c as 4 words:
//   word 0 = tokens 0..3, word 1 = tokens 4..7, ...
// =============================================================================
`timescale 1ns/1ps

module tb_snax_streamer_write_out;

    localparam int DATA_WIDTH = 72;
    localparam int ADDR_WIDTH = 32;
    localparam int NUM_LANES  = 16;
    localparam int STRB_WIDTH = 9;
    localparam int CLK_PERIOD = 10;
    localparam int N_TOK      = 16;
    localparam int N_CH       = 16;

    logic clk, rst_n;

    logic        csr_start;
    logic        busy, done;
    logic        cfg_transpose;
    logic [31:0] cfg_base, cfg_num_vectors, cfg_line_stride;

    logic [NUM_LANES*16-1:0] core_fp16;
    logic                    core_fp16_valid;
    logic                    core_fp16_ready;
    logic [DATA_WIDTH-1:0]   core_fp4;
    logic                    core_fp4_valid;
    logic                    core_fp4_ready;

    logic                    m_req_valid, m_req_write, m_req_ready;
    logic [ADDR_WIDTH-1:0]   m_req_addr;
    logic [DATA_WIDTH-1:0]   m_req_wdata;
    logic [STRB_WIDTH-1:0]   m_req_strb;

    // TCDM write model: [bank][word]
    logic [DATA_WIDTH-1:0] tcdm [0:31][0:1023];

    int match_count, mismatch_count;
    int t, c, w, k;
    logic [15:0] expect_val;
    logic [15:0] actual_val;

    snax_streamer_write_out #(
        .DATA_WIDTH (DATA_WIDTH),
        .ADDR_WIDTH (ADDR_WIDTH),
        .NUM_LANES  (NUM_LANES),
        .STRB_WIDTH (STRB_WIDTH)
    ) dut (
        .clk                    (clk),
        .rst_n                  (rst_n),
        .csr_start_i            (csr_start),
        .busy_o                 (busy),
        .done_irq_o             (done),
        .cfg_mode_transpose_i   (cfg_transpose),
        .cfg_base_addr_i        (cfg_base),
        .cfg_num_vectors_i      (cfg_num_vectors),
        .cfg_line_stride_i      (cfg_line_stride),
        .core_out_fp16_data_i   (core_fp16),
        .core_out_fp16_valid_i  (core_fp16_valid),
        .core_out_fp16_ready_o  (core_fp16_ready),
        .core_out_fp4_data_i    (core_fp4),
        .core_out_fp4_valid_i   (core_fp4_valid),
        .core_out_fp4_ready_o   (core_fp4_ready),
        .m_tcdm_req_valid_o     (m_req_valid),
        .m_tcdm_req_write_o     (m_req_write),
        .m_tcdm_req_addr_o      (m_req_addr),
        .m_tcdm_req_wdata_o     (m_req_wdata),
        .m_tcdm_req_strb_o      (m_req_strb),
        .m_tcdm_req_ready_i     (m_req_ready)
    );

    initial begin
        clk = 0;
        forever #(CLK_PERIOD/2) clk = ~clk;
    end

    function automatic [15:0] pat(input int tok, input int ch);
        pat = 16'hA000 + tok*16 + ch;
    endfunction

    task automatic wait_cycles(input int n);
        repeat (n) @(posedge clk);
    endtask

    // TCDM write model.
    always @(posedge clk) begin
        if (rst_n && m_req_valid && m_req_write && m_req_ready) begin
            tcdm[m_req_addr[8:4]][m_req_addr[18:9]] <= m_req_wdata;
        end
    end

    initial begin
        $display("\n=====================================================");
        $display("   WRITE-OUT TRANSPOSE UNIT TEST: 16 tokens x 16 ch  ");
        $display("=====================================================\n");

        rst_n = 1'b0;
        csr_start = 1'b0;
        cfg_transpose = 1'b1;
        cfg_base = 32'h0000_0000;
        cfg_num_vectors = 32'd1;
        cfg_line_stride = 32'h0000_0800; // 4 words per 16-token vector
        core_fp16 = '0;
        core_fp16_valid = 1'b0;
        core_fp4 = '0;
        core_fp4_valid = 1'b0;
        m_req_ready = 1'b1;

        match_count = 0; mismatch_count = 0;

        wait_cycles(5);
        rst_n = 1'b1;
        wait_cycles(5);

        // Start transpose pass.
        @(negedge clk);
        csr_start = 1'b1;
        @(posedge clk);
        @(negedge clk);
        csr_start = 1'b0;
        wait_cycles(2);

        // Feed 16 tokens, one vector per cycle.
        for (t = 0; t < N_TOK; t = t + 1) begin
            @(negedge clk);
            for (c = 0; c < N_CH; c = c + 1) begin
                core_fp16[c*16 +: 16] = pat(t, c);
            end
            core_fp16_valid = 1'b1;
            @(posedge clk);
        end
        @(negedge clk);
        core_fp16_valid = 1'b0;
        core_fp16 = '0;

        // Wait for the 64-word flush.
        while (busy) @(negedge clk);
        wait_cycles(3);

        // Check channel c, word w, lane k: token = 4*w+k.
        for (c = 0; c < N_CH; c = c + 1) begin
            for (w = 0; w < 4; w = w + 1) begin
                if (tcdm[c][w][71:64] !== 8'h00) begin
                    mismatch_count = mismatch_count + 1;
                    $display("  [MISMATCH] ch=%0d w=%0d scale byte=0x%02X expected 0x00",
                             c, w, tcdm[c][w][71:64]);
                end
                for (k = 0; k < 4; k = k + 1) begin
                    t = w*4 + k;
                    expect_val = pat(t, c);
                    actual_val = tcdm[c][w][k*16 +: 16];
                    if (actual_val === expect_val) begin
                        match_count = match_count + 1;
                    end else begin
                        mismatch_count = mismatch_count + 1;
                        $display("  [MISMATCH] ch=%0d word=%0d slot=%0d tok=%0d actual=0x%04X expect=0x%04X",
                                 c, w, k, t, actual_val, expect_val);
                    end
                end
            end
        end

        $display("\n-----------------------------------------------------");
        $display(" Transpose values checked : %0d", match_count + mismatch_count);
        $display(" Matches                  : %0d", match_count);
        $display(" Mismatches               : %0d", mismatch_count);
        if (mismatch_count == 0 && match_count == N_TOK*N_CH)
            $display(" >>> [PASS] TRANSPOSE FLUSH 16 TOKENS x 16 CHANNELS <<<");
        else
            $display(" >>> [FAIL] TRANSPOSE FLUSH <<<");
        $display("-----------------------------------------------------\n");
        $finish;
    end

endmodule
