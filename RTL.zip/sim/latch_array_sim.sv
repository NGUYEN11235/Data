`timescale 1ns/1ps

// -----------------------------------------------------------------------------
// latch_array_sim.sv
//
// Simulation-only, cycle-equivalent replacement for latch_array.sv.
//
// The original array is 8192 transparent D-latches plus 256 ICG cells for
// ACC_DEPTH=16 x 512 bits.  Verilator flattens every latch/ICG, which dominates
// C++ generation and compile time.  This model keeps the same external timing:
//
//   * write command presented in cycle N is captured at posedge N+1 and is
//     visible to both read ports from cycle N+1 onward;
//   * reads are combinational;
//   * a read in cycle N still returns the old word (read-before-write).
//
// Functionally identical for vsq_matmul_engine's same-cycle RMW use.
// -----------------------------------------------------------------------------
module latch_array #(
    parameter DEPTH = 16,
    parameter DW    = 32,
    parameter ICG_GROUP = 32,   // unused, kept for interface compatibility
    parameter bit USE_FF = 1'b1 // unused
) (
    input  logic                 clk,
    input  logic                 reset_n,

    input  logic [$clog2(DEPTH)-1:0] waddr,
    input  logic [DW-1:0]            wdata,
    input  logic                     wen,
    input  logic                     ren1,
    input  logic                     ren2,
    input  logic [$clog2(DEPTH)-1:0] raddr1,
    input  logic [$clog2(DEPTH)-1:0] raddr2,
    output logic [DW-1:0]            rdata1,
    output logic [DW-1:0]            rdata2
);

    logic [DW-1:0] q_store [0:DEPTH-1];

    always_ff @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin
            for (int i = 0; i < DEPTH; i++) q_store[i] <= '0;
        end else if (wen) begin
            q_store[waddr] <= wdata;
        end
    end

    assign rdata1 = ren1 ? q_store[raddr1] : '0;
    assign rdata2 = ren2 ? q_store[raddr2] : '0;

endmodule
