// =============================================================================
// Module: snax_streamer_write_out
// Description: Linear FP4 / FP16 output writer plus V FP4 batch writer.
//
// Modes:
//   2'd0 : FP4 linear   - one 72b packet per vector
//   2'd1 : FP16 linear  - one 256b FP16 vector -> 4 x 72b words
//   2'd2 : V FP4 batch  - cfg_num_vectors channel packets per batch
//
// V mode address:
//   addr = cfg_base_addr_i + batch * cfg_batch_stride_i
//                        + channel * cfg_line_stride_i
//   Typical V layout: cfg_num_vectors=16, cfg_line_stride=16,
//                     cfg_batch_stride=0x200.
// =============================================================================
`timescale 1ns/1ps

module snax_streamer_write_out #(
    parameter int unsigned DATA_WIDTH = 72,
    parameter int unsigned ADDR_WIDTH = 32,
    parameter int unsigned NUM_LANES  = 16,
    parameter int unsigned STRB_WIDTH = 9
)(
    input  logic                            clk,
    input  logic                            rst_n,

    input  logic                            csr_start_i,
    output logic                            busy_o,
    output logic                            done_irq_o,

    input  logic [1:0]                      cfg_mode_i,          // 0 FP4, 1 FP16, 2 V FP4
    input  logic [ADDR_WIDTH-1:0]           cfg_base_addr_i,
    input  logic [31:0]                     cfg_num_vectors_i,   // packets per batch / linear vectors
    input  logic [31:0]                     cfg_line_stride_i,    // per packet / per FP16 word / per channel
    input  logic [31:0]                     cfg_num_batches_i,    // V mode batches
    input  logic [31:0]                     cfg_batch_stride_i,   // V mode batch stride

    input  logic [NUM_LANES*16-1:0]         core_out_fp16_data_i,
    input  logic                            core_out_fp16_valid_i,
    output logic                            core_out_fp16_ready_o,

    input  logic [DATA_WIDTH-1:0]           core_out_fp4_data_i,
    input  logic                            core_out_fp4_valid_i,
    output logic                            core_out_fp4_ready_o,

    output logic                            m_tcdm_req_valid_o,
    output logic                            m_tcdm_req_write_o,
    output logic [ADDR_WIDTH-1:0]           m_tcdm_req_addr_o,
    output logic [DATA_WIDTH-1:0]           m_tcdm_req_wdata_o,
    output logic [STRB_WIDTH-1:0]           m_tcdm_req_strb_o,
    input  logic                            m_tcdm_req_ready_i
);

    localparam logic [1:0] MODE_FP4  = 2'd0;
    localparam logic [1:0] MODE_FP16 = 2'd1;
    localparam logic [1:0] MODE_V    = 2'd2;

    typedef enum logic [1:0] {
        IDLE,
        WRITE_FP4,
        WRITE_FP16,
        WRITE_V
    } state_t;

    state_t state_q, state_d;

    logic [31:0]           vec_cnt_q,    vec_cnt_d;
    logic [31:0]           batch_cnt_q,  batch_cnt_d;
    logic [ADDR_WIDTH-1:0] write_addr_q, write_addr_d;
    logic [ADDR_WIDTH-1:0] batch_base_q, batch_base_d;
    logic [1:0]            word_cnt_q,   word_cnt_d;
    logic [NUM_LANES*16-1:0] fp16_vec_q, fp16_vec_d;
    logic                  fp16_active_q, fp16_active_d;
    logic                  start_q;

    wire tcdm_fire   = m_tcdm_req_valid_o && m_tcdm_req_ready_i;
    wire start_pulse = csr_start_i && !start_q;

    function automatic logic [DATA_WIDTH-1:0] pack_fp16_word(
        input logic [NUM_LANES*16-1:0] vec,
        input logic [1:0] word
    );
        pack_fp16_word = {8'h00,
                          vec[(word*4 + 3)*16 +: 16],
                          vec[(word*4 + 2)*16 +: 16],
                          vec[(word*4 + 1)*16 +: 16],
                          vec[(word*4 + 0)*16 +: 16]};
    endfunction

    always_comb begin
        state_d               = state_q;
        vec_cnt_d             = vec_cnt_q;
        batch_cnt_d           = batch_cnt_q;
        write_addr_d          = write_addr_q;
        batch_base_d          = batch_base_q;
        word_cnt_d            = word_cnt_q;
        fp16_vec_d            = fp16_vec_q;
        fp16_active_d         = fp16_active_q;
        done_irq_o            = 1'b0;
        core_out_fp16_ready_o = 1'b0;
        core_out_fp4_ready_o  = 1'b0;

        m_tcdm_req_valid_o = 1'b0;
        m_tcdm_req_write_o = 1'b1;
        m_tcdm_req_addr_o  = write_addr_q;
        m_tcdm_req_wdata_o = '0;
        m_tcdm_req_strb_o  = '1;

        case (state_q)
            IDLE: begin
                if (start_pulse) begin
                    if ((cfg_num_vectors_i == 0) ||
                        ((cfg_mode_i == MODE_V) && (cfg_num_batches_i == 0))) begin
                        done_irq_o = 1'b1;
                    end else begin
                        vec_cnt_d     = '0;
                        batch_cnt_d   = '0;
                        write_addr_d  = cfg_base_addr_i;
                        batch_base_d  = cfg_base_addr_i;
                        word_cnt_d    = '0;
                        fp16_active_d = 1'b0;
                        case (cfg_mode_i)
                            MODE_FP16: state_d = WRITE_FP16;
                            MODE_V:    state_d = WRITE_V;
                            default:   state_d = WRITE_FP4;
                        endcase
                    end
                end
            end

            // -------------------------------------------------------------
            // Linear FP4: one 72b packet per vector
            // -------------------------------------------------------------
            WRITE_FP4: begin
                core_out_fp4_ready_o = m_tcdm_req_ready_i;

                if (core_out_fp4_valid_i) begin
                    m_tcdm_req_valid_o = 1'b1;
                    m_tcdm_req_wdata_o = core_out_fp4_data_i;

                    if (tcdm_fire) begin
                        write_addr_d = write_addr_q + cfg_line_stride_i;

                        if (vec_cnt_q < cfg_num_vectors_i - 1'b1) begin
                            vec_cnt_d = vec_cnt_q + 1'b1;
                        end else begin
                            done_irq_o = 1'b1;
                            state_d    = IDLE;
                        end
                    end
                end
            end

            // -------------------------------------------------------------
            // Linear FP16: one 256b vector -> 4 x 72b words
            // -------------------------------------------------------------
            WRITE_FP16: begin
                core_out_fp16_ready_o = !fp16_active_q;

                if (!fp16_active_q) begin
                    if (core_out_fp16_valid_i) begin
                        fp16_vec_d    = core_out_fp16_data_i;
                        fp16_active_d = 1'b1;
                        word_cnt_d    = '0;
                    end
                end else begin
                    m_tcdm_req_valid_o = 1'b1;
                    m_tcdm_req_wdata_o = pack_fp16_word(fp16_vec_q, word_cnt_q);

                    if (tcdm_fire) begin
                        write_addr_d = write_addr_q + cfg_line_stride_i;

                        if (word_cnt_q < 2'd3) begin
                            word_cnt_d = word_cnt_q + 1'b1;
                        end else begin
                            word_cnt_d    = '0;
                            fp16_active_d = 1'b0;

                            if (vec_cnt_q < cfg_num_vectors_i - 1'b1) begin
                                vec_cnt_d = vec_cnt_q + 1'b1;
                            end else begin
                                done_irq_o = 1'b1;
                                state_d    = IDLE;
                            end
                        end
                    end
                end
            end

            // -------------------------------------------------------------
            // V FP4 batch: cfg_num_vectors channel packets per batch
            // -------------------------------------------------------------
            WRITE_V: begin
                core_out_fp4_ready_o = m_tcdm_req_ready_i;

                if (core_out_fp4_valid_i) begin
                    m_tcdm_req_valid_o = 1'b1;
                    m_tcdm_req_wdata_o = core_out_fp4_data_i;

                    if (tcdm_fire) begin
                        write_addr_d = write_addr_q + cfg_line_stride_i;

                        if (vec_cnt_q < cfg_num_vectors_i - 1'b1) begin
                            vec_cnt_d = vec_cnt_q + 1'b1;
                        end else begin
                            vec_cnt_d = '0;

                            if (batch_cnt_q < cfg_num_batches_i - 1'b1) begin
                                batch_cnt_d  = batch_cnt_q + 1'b1;
                                batch_base_d = batch_base_q + cfg_batch_stride_i;
                                write_addr_d = batch_base_q + cfg_batch_stride_i;
                            end else begin
                                done_irq_o = 1'b1;
                                state_d    = IDLE;
                            end
                        end
                    end
                end
            end

            default: state_d = IDLE;
        endcase
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_q       <= IDLE;
            vec_cnt_q     <= '0;
            batch_cnt_q   <= '0;
            write_addr_q  <= '0;
            batch_base_q  <= '0;
            word_cnt_q    <= '0;
            fp16_vec_q    <= '0;
            fp16_active_q <= 1'b0;
            start_q       <= 1'b0;
        end else begin
            state_q       <= state_d;
            vec_cnt_q     <= vec_cnt_d;
            batch_cnt_q   <= batch_cnt_d;
            write_addr_q  <= write_addr_d;
            batch_base_q  <= batch_base_d;
            word_cnt_q    <= word_cnt_d;
            fp16_vec_q    <= fp16_vec_d;
            fp16_active_q <= fp16_active_d;
            start_q       <= csr_start_i;
        end
    end

    assign busy_o = (state_q != IDLE);

endmodule
