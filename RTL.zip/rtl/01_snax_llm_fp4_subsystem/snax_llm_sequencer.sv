// =============================================================================
// Module: snax_llm_sequencer.sv
// Description: Complete, Production-Grade Hardware Orchestration Sequencer for
//              SNAX FP4 LLM Subsystem.
//
// Key Features:
//   1. Multi-Mode Workload Support:
//      - OP_ATTN (FlashAttention: 4-level nested loops: Head, Q-tile, DV-slice, KV-tile)
//      - OP_GEMM (Dense GeMM: Output-Stationary over 16 Lanes x 16 Latch Slots)
//   2. Credit-Based TCDM Ring Buffer Management:
//      - Treats TCDM as an N-slot circular sliding window.
//      - Asynchronously issues DMA prefetch commands to hide DRAM latency.
//      - Credit tracking guarantees zero RAW / WAR hazards without lockstep stalls.
//   3. Dynamic Hardware Causal Mask Generator:
//      - Computes 16-bit causal masks on-the-fly from (q_idx, kv_idx).
//   4. Decoupled Event-Driven Execution:
//      - Zero-bubble handshakes, robust p_fifo backpressure handling.
// =============================================================================

`timescale 1ns/1ps

module snax_llm_sequencer #(
    parameter int unsigned ADDR_WIDTH      = 32,
    parameter int unsigned NUM_LANES       = 16,
    parameter int unsigned NUM_RING_SLOTS  = 4,   // TCDM Circular Buffer Depth
    parameter int unsigned SLOT_SIZE_BYTES = 16 * 1024 // 16 KB per Ring Slot
)(
    input  logic                                clk,
    input  logic                                rst_n,

    // =========================================================================
    // 1. TOP-LEVEL JOB CONTROL & CONFIGURATION DESCRIPTOR
    // =========================================================================
    input  logic                                start_i,
    output logic                                busy_o,
    output logic                                done_o,

    // Opcode selection
    input  logic [1:0]                          cfg_op_mode_i,       // 00: GEMM, 01: FlashAttention, 10: Transpose/Quant
    input  logic                                cfg_is_causal_i,     // 1: Enable causal autoregressive masking
    input  logic                                cfg_enable_dma_i,    // 1: Enable autonomous DMA prefetching via Ring Buffer

    // Attention Dimensions
    input  logic [7:0]                          cfg_attn_h_i,        // Number of Heads (H)
    input  logic [15:0]                         cfg_attn_q_tiles_i,  // Total Q-Tiles (N_Q / M_Q)
    input  logic [3:0]                          cfg_attn_m_q_i,      // Query tokens per tile (Default: 8)
    input  logic [15:0]                         cfg_attn_dv_tiles_i, // D_V Slices (D_V / 16)
    input  logic [15:0]                         cfg_attn_kv_tiles_i, // KV Tiles (SeqLen_KV / 16)
    input  logic [15:0]                         cfg_attn_k_blocks_i, // D_K Blocks (D_K / 16)

    // GEMM Dimensions
    input  logic [15:0]                         cfg_gemm_n_tiles_i,  // N Output Channel Tiles (N / 16)
    input  logic [15:0]                         cfg_gemm_m_tiles_i,  // M Token Tiles (M / 16)
    input  logic [15:0]                         cfg_gemm_k_blocks_i, // K Reduction Blocks (K / 16)

    // Base Addresses & Strides (TCDM & DRAM)
    input  logic [ADDR_WIDTH-1:0]               cfg_tcdm_ring_base_i,// TCDM Base for circular buffer
    input  logic [ADDR_WIDTH-1:0]               cfg_tcdm_q_base_i,   // TCDM Base for Q/Act
    input  logic [ADDR_WIDTH-1:0]               cfg_tcdm_out_base_i, // TCDM Base for Result Output
    input  logic [ADDR_WIDTH-1:0]               cfg_dram_kv_base_i,  // DRAM Base for KV-Cache / Weights
    input  logic [31:0]                         cfg_stride_tile_i,   // Stride between tiles in bytes

    // =========================================================================
    // 2. DMA MASTER INTERFACE (MASTER 0 CO-PROCESSOR HANDSHAKE)
    // =========================================================================
    output logic                                dma_req_valid_o,
    input  logic                                dma_req_ready_i,
    output logic [1:0]                          dma_req_dir_o,       // 0: DRAM -> TCDM, 1: TCDM -> DRAM
    output logic [ADDR_WIDTH-1:0]               dma_req_dram_addr_o,
    output logic [ADDR_WIDTH-1:0]               dma_req_tcdm_addr_o,
    output logic [31:0]                         dma_req_size_bytes_o,
    input  logic                                dma_done_i,

    // =========================================================================
    // 3. ACTIVATION STREAMER INTERFACE (MASTER 2)
    // =========================================================================
    output logic                                act_start_o,
    output logic [ADDR_WIDTH-1:0]               act_base_o,
    output logic [31:0]                         act_k_blocks_o,
    output logic [31:0]                         act_k_stride_o,
    output logic [31:0]                         act_tokens_o,
    output logic [31:0]                         act_token_stride_o,
    input  logic                                act_busy_i,
    input  logic                                act_valid_i,
    output logic                                act_ready_o,

    // =========================================================================
    // 4. 16-CHANNEL WEIGHT / KV STREAMER INTERFACE (MASTERS 3..18)
    // =========================================================================
    output logic                                wt_start_o,
    output logic [ADDR_WIDTH-1:0]               wt_base_o,
    output logic [31:0]                         wt_repeat_o,
    output logic [31:0]                         wt_k_blocks_o,
    output logic [31:0]                         wt_k_stride_o,
    output logic [31:0]                         wt_num_tiles_o,
    output logic [31:0]                         wt_tile_step_o,
    input  logic                                wt_busy_i,
    input  logic [NUM_LANES-1:0]                wt_valid_i,
    output logic [NUM_LANES-1:0]                wt_ready_o,

    // =========================================================================
    // 5. WRITE-OUT STREAMER INTERFACE (MASTER 19)
    // =========================================================================
    output logic                                wo_start_o,
    output logic [1:0]                          wo_mode_o,           // 0: FP4 linear, 1: FP16 linear, 2: V FP4 batch
    output logic [ADDR_WIDTH-1:0]               wo_base_o,
    output logic [31:0]                         wo_num_vectors_o,
    output logic [31:0]                         wo_line_stride_o,
    input  logic                                wo_busy_i,
    input  logic                                wo_done_i,

    // =========================================================================
    // 6. SNAX FUSED LLM COMPUTE CORE CONTROL
    // =========================================================================
    output logic [1:0]                          cfg_mode_o,          // 00: GEMM, 01: QK, 10: PV
    output logic                                cfg_row_start_o,
    output logic [NUM_LANES-1:0]                cfg_key_mask_o,
    output logic                                cfg_enable_slq_o,
    output logic                                tile_drain_req_o,
    output logic [3:0]                          tile_drain_idx_o,
    output logic                                tile_clear_on_drain_o,
    output logic [NUM_LANES-1:0]                lane_valid_o,
    output logic [3:0]                          lane_acc_idx_o,
    input  logic                                p_fifo_empty_i,
    input  logic                                p_fifo_almost_full_i,
    input  logic                                core_fp16_valid_i
);

    // =========================================================================
    // LOCAL TYPEDEFS & PARAMETERS
    // =========================================================================
    localparam int unsigned PTR_W = (NUM_RING_SLOTS > 1) ? $clog2(NUM_RING_SLOTS) : 1;
    localparam int unsigned CNT_W = $clog2(NUM_RING_SLOTS + 1);

    typedef enum logic [3:0] {
        ST_IDLE,
        ST_PREP_DRAIN,
        ST_PREFETCH_INIT,
        // FlashAttention Phases
        ST_ATTN_QK_LAUNCH,
        ST_ATTN_QK_RUN,
        ST_ATTN_SM_DRAIN,
        ST_ATTN_PV_LAUNCH,
        ST_ATTN_PV_RUN,
        ST_ATTN_NORM_DRAIN,
        // GEMM Phases
        ST_GEMM_LAUNCH,
        ST_GEMM_RUN,
        ST_GEMM_DRAIN,
        // Epilogue
        ST_WAIT_WRITE_OUT,
        ST_DONE
    } state_t;

    state_t state_q, state_d;

    // =========================================================================
    // 1. CREDIT-BASED TCDM RING BUFFER CONTROLLER
    // =========================================================================
    logic [PTR_W-1:0] ring_wr_ptr_q;
    logic [PTR_W-1:0] ring_rd_ptr_q;
    logic [CNT_W-1:0] free_credits_q;
    logic [CNT_W-1:0] ready_tiles_q;

    wire dma_can_push = (free_credits_q > '0) && cfg_enable_dma_i;
    wire core_can_pop = (ready_tiles_q > '0)  || !cfg_enable_dma_i; // Bypass if DMA disabled

    logic dma_issue_fire;
    logic core_release_credit_pulse;
    logic [ADDR_WIDTH-1:0] dma_curr_tcdm_addr;
    logic [ADDR_WIDTH-1:0] core_curr_tcdm_addr;

    assign dma_curr_tcdm_addr  = cfg_tcdm_ring_base_i + ({16'd0, ring_wr_ptr_q} * SLOT_SIZE_BYTES);
    assign core_curr_tcdm_addr = cfg_enable_dma_i 
                               ? (cfg_tcdm_ring_base_i + ({16'd0, ring_rd_ptr_q} * SLOT_SIZE_BYTES))
                               : cfg_tcdm_ring_base_i; // Fallback to direct base

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ring_wr_ptr_q   <= '0;
            ring_rd_ptr_q   <= '0;
            free_credits_q  <= NUM_RING_SLOTS[CNT_W-1:0];
            ready_tiles_q   <= '0;
        end else if (start_i) begin
            ring_wr_ptr_q   <= '0;
            ring_rd_ptr_q   <= '0;
            free_credits_q  <= NUM_RING_SLOTS[CNT_W-1:0];
            ready_tiles_q   <= '0;
        end else begin
            // Producer (DMA) credit consumption
            if (dma_issue_fire && !core_release_credit_pulse)
                free_credits_q <= free_credits_q - 1'b1;
            else if (!dma_issue_fire && core_release_credit_pulse)
                free_credits_q <= free_credits_q + 1'b1;

            if (dma_issue_fire)
                ring_wr_ptr_q <= (ring_wr_ptr_q == PTR_W'(NUM_RING_SLOTS - 1)) ? '0 : ring_wr_ptr_q + 1'b1;

            // Consumer (Core) ready tile update
            if (dma_done_i && !core_release_credit_pulse)
                ready_tiles_q <= ready_tiles_q + 1'b1;
            else if (!dma_done_i && core_release_credit_pulse)
                ready_tiles_q <= ready_tiles_q - 1'b1;

            if (core_release_credit_pulse)
                ring_rd_ptr_q <= (ring_rd_ptr_q == PTR_W'(NUM_RING_SLOTS - 1)) ? '0 : ring_rd_ptr_q + 1'b1;
        end
    end

    // =========================================================================
    // 2. 5D HIERARCHICAL LOOP NEST ENGINE
    // =========================================================================
    // Attention Counters
    logic [7:0]   cnt_h_q;
    logic [15:0]  cnt_qi_q;
    logic [15:0]  cnt_dvi_q;
    logic [15:0]  cnt_kj_q;
    logic [15:0]  cnt_kb_q;
    logic [3:0]   cnt_m_q;

    // Attention Addresses (matches FlashAttention layout)
    wire [31:0] q_addr_calc = cfg_tcdm_q_base_i + 
                             ((32'(cnt_h_q) * 32'd32 + 32'(cnt_qi_q) * 32'(cfg_attn_m_q_i) * 32'd2 + 32'(cnt_kb_q)) * 32'h200);
    wire [31:0] k_addr_calc = cfg_tcdm_ring_base_i + 
                             ((32'(cnt_h_q) * 32'd4 + 32'(cnt_kj_q) * 32'd2) * 32'h200);
    wire [31:0] v_addr_calc = cfg_tcdm_ring_base_i + 
                             ((32'd16 + 32'(cnt_h_q) * 32'd4 + 32'(cnt_dvi_q) * 32'd2 + 32'(cnt_kj_q)) * 32'h200);

    // GEMM Counters
    logic [15:0]  cnt_gn_q; // GEMM N-tile
    logic [15:0]  cnt_gm_q; // GEMM M-tile
    logic [15:0]  cnt_gk_q; // GEMM K-block
    logic [3:0]   cnt_gbeat_q;

    wire last_m_beat  = (cnt_m_q == (cfg_attn_m_q_i - 4'd1));
    wire last_kb      = (cnt_kb_q == (cfg_attn_k_blocks_i - 16'd1));
    wire last_kj      = (cnt_kj_q == (cfg_attn_kv_tiles_i - 16'd1));
    wire last_dvi     = (cnt_dvi_q == (cfg_attn_dv_tiles_i - 16'd1));
    wire last_qi      = (cnt_qi_q == (cfg_attn_q_tiles_i - 16'd1));
    wire last_h       = (cnt_h_q == (cfg_attn_h_i - 8'd1));

    wire last_gbeat   = (cnt_gbeat_q == 4'd15);
    wire last_gk      = (cnt_gk_q == (cfg_gemm_k_blocks_i - 16'd1));
    wire last_gm      = (cnt_gm_q == (cfg_gemm_m_tiles_i - 16'd1));
    wire last_gn      = (cnt_gn_q == (cfg_gemm_n_tiles_i - 16'd1));

    // =========================================================================
    // 3. HARDWARE DYNAMIC CAUSAL MASK GENERATOR
    // =========================================================================
    logic [NUM_LANES-1:0] auto_causal_mask;
    always_comb begin
        if (!cfg_is_causal_i) begin
            auto_causal_mask = 16'hFFFF;
        end else begin
            for (int l = 0; l < 16; l++) begin
                // Causal logic: key_absolute_index <= query_absolute_index
                // Key index = kj * 16 + l
                // Query index = qi * M_Q + m
                auto_causal_mask[l] = ((32'(cnt_kj_q) * 32'd16 + 32'(l)) <= 
                                       (32'(cnt_qi_q) * 32'(cfg_attn_m_q_i) + 32'(cnt_m_q)));
            end
        end
    end

    // =========================================================================
    // 4. MICRO-FSM EXECUTION COORDINATOR
    // =========================================================================
    logic qk_compute_fire;
    logic pv_compute_fire;
    logic gemm_compute_fire;

    assign qk_compute_fire   = act_valid_i && (&wt_valid_i);
    assign pv_compute_fire   = !p_fifo_empty_i && (&wt_valid_i);
    assign gemm_compute_fire = act_valid_i && (&wt_valid_i);

    always_comb begin
        state_d                   = state_q;
        dma_req_valid_o           = 1'b0;
        dma_req_dir_o             = 2'd0; // DRAM -> TCDM
        dma_req_dram_addr_o       = cfg_dram_kv_base_i + (32'(cnt_kj_q) * cfg_stride_tile_i);
        dma_req_tcdm_addr_o       = dma_curr_tcdm_addr;
        dma_req_size_bytes_o      = SLOT_SIZE_BYTES;
        dma_issue_fire            = 1'b0;
        core_release_credit_pulse = 1'b0;

        act_start_o               = 1'b0;
        act_base_o                = cfg_tcdm_q_base_i;
        act_k_blocks_o            = 32'd1;
        act_k_stride_o            = 32'd0;
        act_tokens_o              = 32'(cfg_attn_m_q_i);
        act_token_stride_o        = 32'h200;
        act_ready_o               = 1'b0;

        wt_start_o                = 1'b0;
        wt_base_o                 = core_curr_tcdm_addr;
        wt_repeat_o               = 32'(cfg_attn_m_q_i);
        wt_k_blocks_o             = 32'd1;
        wt_k_stride_o             = 32'h200;
        wt_num_tiles_o            = 32'd1;
        wt_tile_step_o            = 32'd0;
        wt_ready_o                = 16'h0000;

        wo_start_o                = 1'b0;
        wo_mode_o                 = 2'd1; // Default FP16
        wo_base_o                 = cfg_tcdm_out_base_i;
        wo_num_vectors_o          = 32'd16;
        wo_line_stride_o          = 32'h200;

        cfg_mode_o                = 2'b00;
        cfg_row_start_o           = 1'b0;
        cfg_key_mask_o            = auto_causal_mask;
        cfg_enable_slq_o          = 1'b1;

        tile_drain_req_o          = 1'b0;
        tile_drain_idx_o          = 4'd0;
        tile_clear_on_drain_o     = 1'b0;
        lane_valid_o              = 16'h0000;
        lane_acc_idx_o            = 4'd0;

        case (state_q)
            ST_IDLE: begin
                if (start_i) begin
                    state_d = ST_PREP_DRAIN;
                end
            end

            ST_PREP_DRAIN: begin
                // Pre-configure Write-Out Streamer for results
                wo_start_o       = 1'b1;
                wo_mode_o        = 2'd1; // FP16 out
                wo_base_o        = cfg_tcdm_out_base_i;
                wo_num_vectors_o = (cfg_op_mode_i == 2'b00)
                                 ? (32'(cfg_gemm_m_tiles_i) * 32'(cfg_gemm_n_tiles_i) * 32'd16)
                                 : (32'(cfg_attn_h_i) * 32'(cfg_attn_q_tiles_i) * 32'(cfg_attn_dv_tiles_i) * 32'(cfg_attn_m_q_i));
                state_d = ST_PREFETCH_INIT;
            end

            ST_PREFETCH_INIT: begin
                // Kick off initial DMA prefetch if enabled
                if (cfg_enable_dma_i && dma_can_push) begin
                    dma_req_valid_o      = 1'b1;
                    dma_req_dram_addr_o  = cfg_dram_kv_base_i;
                    if (dma_req_ready_i) begin
                        dma_issue_fire   = 1'b1;
                        state_d          = (cfg_op_mode_i == 2'b00) ? ST_GEMM_LAUNCH : ST_ATTN_QK_LAUNCH;
                    end
                end else begin
                    state_d = (cfg_op_mode_i == 2'b00) ? ST_GEMM_LAUNCH : ST_ATTN_QK_LAUNCH;
                end
            end

            // =================================================================
            // FLASHATTENTION PATH
            // =================================================================
            ST_ATTN_QK_LAUNCH: begin
                if (core_can_pop && !act_busy_i && !wt_busy_i) begin
                    cfg_mode_o         = 2'b01; // Attn Q*K
                    // Launch K streamer on core buffer
                    wt_start_o         = 1'b1;
                    wt_base_o          = cfg_enable_dma_i ? core_curr_tcdm_addr : k_addr_calc;
                    wt_repeat_o        = 32'(cfg_attn_m_q_i);
                    wt_k_blocks_o      = 32'(cfg_attn_k_blocks_i);
                    wt_k_stride_o      = 32'h200;

                    // Launch Q streamer
                    act_start_o        = 1'b1;
                    act_base_o         = q_addr_calc;
                    act_tokens_o       = 32'(cfg_attn_m_q_i);
                    act_token_stride_o = 32'h400; // 2 * 32'h200
                    act_k_blocks_o     = 32'd1;

                    state_d            = ST_ATTN_QK_RUN;
                end
            end

            ST_ATTN_QK_RUN: begin
                cfg_mode_o = 2'b01;
                if (qk_compute_fire) begin
                    lane_valid_o   = 16'hFFFF;
                    lane_acc_idx_o = {1'b1, cnt_m_q[2:0]}; // Accumulate in Slots 8..15
                    act_ready_o    = 1'b1;
                    wt_ready_o     = 16'hFFFF;

                    if (last_m_beat) begin
                        if (last_kb) begin
                            state_d = ST_ATTN_SM_DRAIN;
                        end
                    end
                end
            end

            ST_ATTN_SM_DRAIN: begin
                cfg_mode_o = 2'b01;
                // Wait until p_fifo has room before draining
                if (!p_fifo_almost_full_i) begin
                    tile_drain_req_o      = 1'b1;
                    tile_drain_idx_o      = {1'b1, cnt_m_q[2:0]}; // Drain S slot
                    tile_clear_on_drain_o = 1'b1;
                    cfg_row_start_o       = (cnt_kj_q == 16'd0) && (cnt_dvi_q == 16'd0); // New row start
                    state_d               = ST_ATTN_PV_LAUNCH;
                end
            end

            ST_ATTN_PV_LAUNCH: begin
                if (!wt_busy_i) begin
                    cfg_mode_o    = 2'b10; // Attn P*V
                    // Launch V streamer
                    wt_start_o    = 1'b1;
                    wt_base_o     = cfg_enable_dma_i ? (core_curr_tcdm_addr + 32'h1000) : v_addr_calc;
                    wt_repeat_o   = 32'(cfg_attn_m_q_i);
                    wt_k_blocks_o = 32'd1;
                    wt_k_stride_o = 32'd0;
                    state_d       = ST_ATTN_PV_RUN;
                end
            end

            ST_ATTN_PV_RUN: begin
                cfg_mode_o = 2'b10;
                if (pv_compute_fire) begin
                    lane_valid_o   = 16'hFFFF;
                    lane_acc_idx_o = {1'b0, cnt_m_q[2:0]}; // Accumulate O in Slots 0..7
                    wt_ready_o     = 16'hFFFF;

                    if (last_m_beat) begin
                        // Core completed one full KV tile! Return credit to ring buffer
                        core_release_credit_pulse = cfg_enable_dma_i;

                        if (last_kj) begin
                            // Reached end of entire KV sequence for this dvi slice! Drain O!
                            state_d = ST_ATTN_NORM_DRAIN;
                        end else begin
                            state_d = ST_ATTN_QK_LAUNCH;
                        end
                    end
                end
            end

            ST_ATTN_NORM_DRAIN: begin
                cfg_mode_o            = 2'b10;
                tile_drain_req_o      = 1'b1;
                tile_drain_idx_o      = {1'b0, cnt_m_q[2:0]}; // Drain O slots
                tile_clear_on_drain_o = 1'b1; // Clear O for next dvi slice

                if (last_m_beat && core_fp16_valid_i) begin
                    if (last_dvi && last_qi && last_h) begin
                        state_d = ST_WAIT_WRITE_OUT;
                    end else begin
                        state_d = ST_ATTN_QK_LAUNCH;
                    end
                end
            end

            // =================================================================
            // DENSE GEMM PATH
            // =================================================================
            ST_GEMM_LAUNCH: begin
                if (core_can_pop && !act_busy_i && !wt_busy_i) begin
                    cfg_mode_o    = 2'b00; // Mode 00: GEMM
                    // Launch Weight Streamer (16 Output Channels)
                    wt_start_o    = 1'b1;
                    wt_base_o     = core_curr_tcdm_addr;
                    wt_repeat_o   = 32'd16; // 16 Tokens
                    wt_k_blocks_o = 32'd1;

                    // Launch Act Streamer
                    act_start_o   = 1'b1;
                    act_base_o    = cfg_tcdm_q_base_i + (32'(cnt_gm_q) * 32'd16 * 32'h200);
                    act_tokens_o  = 32'd16;
                    act_k_blocks_o= 32'd1;

                    state_d       = ST_GEMM_RUN;
                end
            end

            ST_GEMM_RUN: begin
                cfg_mode_o = 2'b00;
                if (gemm_compute_fire) begin
                    lane_valid_o   = 16'hFFFF;
                    lane_acc_idx_o = cnt_gbeat_q; // Full 16 slots [0..15]
                    act_ready_o    = 1'b1;
                    wt_ready_o     = 16'hFFFF;

                    if (last_gbeat) begin
                        if (last_gk) begin
                            state_d = ST_GEMM_DRAIN;
                        end else begin
                            state_d = ST_GEMM_LAUNCH; // Next K-block accumulation
                        end
                    end
                end
            end

            ST_GEMM_DRAIN: begin
                cfg_mode_o            = 2'b00;
                tile_drain_req_o      = 1'b1;
                tile_drain_idx_o      = cnt_gbeat_q;
                tile_clear_on_drain_o = 1'b1;

                if (last_gbeat && core_fp16_valid_i) begin
                    core_release_credit_pulse = cfg_enable_dma_i;
                    if (last_gm && last_gn) begin
                        state_d = ST_WAIT_WRITE_OUT;
                    end else begin
                        state_d = ST_GEMM_LAUNCH;
                    end
                end
            end

            ST_WAIT_WRITE_OUT: begin
                if (wo_done_i || !wo_busy_i) begin
                    state_d = ST_DONE;
                end
            end

            ST_DONE: begin
                state_d = ST_IDLE;
            end

            default: state_d = ST_IDLE;
        endcase
    end

    // Sequential state & counter register updates
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_q     <= ST_IDLE;
            cnt_h_q     <= '0;
            cnt_qi_q    <= '0;
            cnt_dvi_q   <= '0;
            cnt_kj_q    <= '0;
            cnt_kb_q    <= '0;
            cnt_m_q     <= '0;
            cnt_gn_q    <= '0;
            cnt_gm_q    <= '0;
            cnt_gk_q    <= '0;
            cnt_gbeat_q <= '0;
        end else begin
            state_q <= state_d;

            if (start_i) begin
                cnt_h_q     <= '0;
                cnt_qi_q    <= '0;
                cnt_dvi_q   <= '0;
                cnt_kj_q    <= '0;
                cnt_kb_q    <= '0;
                cnt_m_q     <= '0;
                cnt_gn_q    <= '0;
                cnt_gm_q    <= '0;
                cnt_gk_q    <= '0;
                cnt_gbeat_q <= '0;
            end else begin
                // Attention Counter Progression
                if ((state_q == ST_ATTN_QK_RUN && qk_compute_fire) ||
                    (state_q == ST_ATTN_PV_RUN && pv_compute_fire)) begin
                    if (last_m_beat) begin
                        cnt_m_q <= '0;
                        if (state_q == ST_ATTN_QK_RUN) begin
                            if (last_kb) cnt_kb_q <= '0;
                            else         cnt_kb_q <= cnt_kb_q + 1'b1;
                        end else begin // ST_ATTN_PV_RUN
                            if (last_kj) begin
                                cnt_kj_q <= '0;
                                if (last_dvi) begin
                                    cnt_dvi_q <= '0;
                                    if (last_qi) begin
                                        cnt_qi_q <= '0;
                                        if (last_h) cnt_h_q <= '0;
                                        else        cnt_h_q <= cnt_h_q + 1'b1;
                                    end else cnt_qi_q <= cnt_qi_q + 1'b1;
                                end else cnt_dvi_q <= cnt_dvi_q + 1'b1;
                            end else cnt_kj_q <= cnt_kj_q + 1'b1;
                        end
                    end else begin
                        cnt_m_q <= cnt_m_q + 1'b1;
                    end
                end

                // GEMM Counter Progression
                if (state_q == ST_GEMM_RUN && gemm_compute_fire) begin
                    if (last_gbeat) begin
                        cnt_gbeat_q <= '0;
                        if (last_gk) begin
                            cnt_gk_q <= '0;
                            if (last_gm) begin
                                cnt_gm_q <= '0;
                                if (last_gn) cnt_gn_q <= '0;
                                else         cnt_gn_q <= cnt_gn_q + 1'b1;
                            end else cnt_gm_q <= cnt_gm_q + 1'b1;
                        end else cnt_gk_q <= cnt_gk_q + 1'b1;
                    end else begin
                        cnt_gbeat_q <= cnt_gbeat_q + 1'b1;
                    end
                end

                if (state_q == ST_GEMM_DRAIN || state_q == ST_ATTN_NORM_DRAIN) begin
                    cnt_gbeat_q <= cnt_gbeat_q + 1'b1;
                end
            end
        end
    end

    assign busy_o = (state_q != ST_IDLE);
    assign done_o = (state_q == ST_DONE);

endmodule
