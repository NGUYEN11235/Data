`timescale 1ns/1ps

module snax_v_quant_path #(
    parameter int unsigned NUM_LANES  = 16,
    parameter int unsigned DATA_WIDTH = 72,
    parameter int unsigned ADDR_WIDTH = 32,
    parameter int unsigned STRB_WIDTH = 9
)(
    input  logic                              clk,
    input  logic                              rst_n,

    input  logic                              csr_start_i,
    output logic                              busy_o,
    output logic                              done_irq_o,

    input  logic [ADDR_WIDTH-1:0]             cfg_base_addr_i,
    input  logic [31:0]                       cfg_num_batches_i,

    input  logic [NUM_LANES*16-1:0]           core_out_fp16_data_i,
    input  logic                              core_out_fp16_valid_i,
    output logic                              core_out_fp16_ready_o,

    output logic                              m_tcdm_req_valid_o,
    output logic                              m_tcdm_req_write_o,
    output logic [ADDR_WIDTH-1:0]             m_tcdm_req_addr_o,
    output logic [DATA_WIDTH-1:0]             m_tcdm_req_wdata_o,
    output logic [STRB_WIDTH-1:0]             m_tcdm_req_strb_o,
    input  logic                              m_tcdm_req_ready_i
);

    typedef enum logic [2:0] {
        IDLE,
        GATHER,
        QUANT,
        WAIT_OUT,
        WRITE
    } state_t;

    state_t state_q, state_d;

    logic [3:0]            gather_cnt_q, gather_cnt_d;
    logic [3:0]            ch_cnt_q,     ch_cnt_d;
    logic [31:0]           batch_cnt_q,  batch_cnt_d;
    logic [ADDR_WIDTH-1:0] base_q,       base_d;
    logic [DATA_WIDTH-1:0] pkt_q,        pkt_d;
    logic                  start_q;

    logic [NUM_LANES-1:0][15:0] col_data;
    logic [DATA_WIDTH-1:0]      logq_packet;
    logic                       logq_out_valid;
    logic                       quant_issue;

    wire tcdm_fire   = m_tcdm_req_valid_o && m_tcdm_req_ready_i;
    wire start_pulse = csr_start_i && !start_q;

    snax_transpose_buffer #(
        .TOKENS     (16),
        .CHANNELS   (NUM_LANES),
        .DATA_WIDTH (16)
    ) u_transpose_buffer (
        .clk     (clk),
        .rst_n   (rst_n),
        .wr_en   (state_q == GATHER && core_out_fp16_valid_i),
        .wr_row  (gather_cnt_q),
        .wr_data (core_out_fp16_data_i),
        .rd_col  (ch_cnt_q),
        .rd_data (col_data)
    );

    log_quantizer #(
        .BLOCK_SIZE   (NUM_LANES),
        .PACKET_WIDTH (DATA_WIDTH)
    ) u_log_quantizer (
        .clk        (clk),
        .reset_n    (rst_n),
        .fp16_in    (col_data),
        .in_valid   (quant_issue),
        .packed_vec (logq_packet),
        .out_valid  (logq_out_valid)
    );

    always_comb begin
        state_d              = state_q;
        gather_cnt_d         = gather_cnt_q;
        ch_cnt_d             = ch_cnt_q;
        batch_cnt_d          = batch_cnt_q;
        base_d               = base_q;
        pkt_d                = pkt_q;
        done_irq_o           = 1'b0;
        core_out_fp16_ready_o = 1'b0;
        quant_issue          = 1'b0;

        m_tcdm_req_valid_o = 1'b0;
        m_tcdm_req_write_o = 1'b1;
        m_tcdm_req_addr_o  = base_q;
        m_tcdm_req_wdata_o = pkt_q;
        m_tcdm_req_strb_o  = '1;

        case (state_q)
            IDLE: begin
                if (start_pulse) begin
                    if (cfg_num_batches_i == 0) begin
                        done_irq_o = 1'b1;
                    end else begin
                        gather_cnt_d = '0;
                        ch_cnt_d     = '0;
                        batch_cnt_d  = '0;
                        base_d       = cfg_base_addr_i;
                        pkt_d        = '0;
                        state_d      = GATHER;
                    end
                end
            end

            GATHER: begin
                core_out_fp16_ready_o = 1'b1;

                if (core_out_fp16_valid_i) begin
                    if (gather_cnt_q < 4'd15) begin
                        gather_cnt_d = gather_cnt_q + 1'b1;
                    end else begin
                        gather_cnt_d = '0;
                        ch_cnt_d     = '0;
                        state_d      = QUANT;
                    end
                end
            end

            QUANT: begin
                quant_issue = 1'b1;
                state_d     = WAIT_OUT;
            end

            WAIT_OUT: begin
                if (logq_out_valid) begin
                    pkt_d   = logq_packet;
                    state_d = WRITE;
                end
            end

            WRITE: begin
                m_tcdm_req_valid_o = 1'b1;
                m_tcdm_req_addr_o  = base_q
                                   + ({28'b0, ch_cnt_q} << 4)
                                   + (batch_cnt_q << 9);
                m_tcdm_req_wdata_o = pkt_q;

                if (tcdm_fire) begin
                    if (ch_cnt_q < 4'd15) begin
                        ch_cnt_d = ch_cnt_q + 1'b1;
                        state_d  = QUANT;
                    end else begin
                        ch_cnt_d = '0;

                        if (batch_cnt_q < cfg_num_batches_i - 1'b1) begin
                            batch_cnt_d = batch_cnt_q + 1'b1;
                            state_d     = GATHER;
                        end else begin
                            done_irq_o = 1'b1;
                            state_d    = IDLE;
                        end
                    end
                end
            end

            default: state_d = IDLE;
        endcase
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_q      <= IDLE;
            gather_cnt_q <= '0;
            ch_cnt_q     <= '0;
            batch_cnt_q  <= '0;
            base_q       <= '0;
            pkt_q        <= '0;
            start_q      <= 1'b0;
        end else begin
            state_q      <= state_d;
            gather_cnt_q <= gather_cnt_d;
            ch_cnt_q     <= ch_cnt_d;
            batch_cnt_q  <= batch_cnt_d;
            base_q       <= base_d;
            pkt_q        <= pkt_d;
            start_q      <= csr_start_i;
        end
    end

    assign busy_o = (state_q != IDLE);

endmodule
