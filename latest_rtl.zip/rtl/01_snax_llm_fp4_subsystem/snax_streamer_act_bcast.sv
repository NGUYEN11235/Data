// =============================================================================
// Module: snax_streamer_act_bcast.sv
// Description: Clean, High-PPA Activation / Query Broadcast Read Streamer
//              - Connects to TCDM Master Port 1 (72-bit DW)
//              - Mode 0 (Prefill/GEMM): 2D AGU Streams K-blocks & Tokens with Skid Buffer
//              - Mode 1 (Decode): Freeze & Latch Mode (Reads 1 word, latches it,
//                broadcasts continuously with ZERO subsequent TCDM accesses!)
// =============================================================================
`timescale 1ns/1ps

module snax_streamer_act_bcast #(
    parameter int unsigned DATA_WIDTH = 72,   // 72-bit Packet (64b FP4 + 8b Exp)
    parameter int unsigned ADDR_WIDTH = 32,   // 32-bit Address
    parameter int unsigned STRB_WIDTH = 9     // 9-bit Strobe
)(
    input  logic                            clk,
    input  logic                            rst_n,

    // -------------------------------------------------------------------------
    // 1. CSR Control & Configuration
    // -------------------------------------------------------------------------
    input  logic                            csr_start_i,
    output logic                            busy_o,
    output logic                            done_irq_o,

    input  logic                            cfg_freeze_mode_i,  // 1: Freeze (Decode); 0: Normal (Prefill)
    input  logic [31:0]                     cfg_freeze_cycles_i,// Số chu kỳ phát lại khi Freeze
    input  logic [ADDR_WIDTH-1:0]           cfg_base_addr_i,    // Địa chỉ gốc trong TCDM (ví dụ Bank 16)
    input  logic [31:0]                     cfg_k_blocks_i,     // Số block K / d_k (Loop 0)
    input  logic [31:0]                     cfg_k_stride_i,     // Bước nhảy block K
    input  logic [31:0]                     cfg_tokens_i,       // Số token trong mẻ (Loop 1)
    input  logic [31:0]                     cfg_token_stride_i, // Bước nhảy token

    // -------------------------------------------------------------------------
    // 2. TCDM Interconnect Master Port 1
    // -------------------------------------------------------------------------
    output logic                            m_tcdm_req_valid_o,
    output logic                            m_tcdm_req_write_o,
    output logic [ADDR_WIDTH-1:0]           m_tcdm_req_addr_o,
    output logic [DATA_WIDTH-1:0]           m_tcdm_req_wdata_o,
    output logic [STRB_WIDTH-1:0]           m_tcdm_req_strb_o,
    input  logic                            m_tcdm_req_ready_i,

    input  logic [DATA_WIDTH-1:0]           m_tcdm_rsp_rdata_i,
    input  logic                            m_tcdm_rsp_valid_i,

    // -------------------------------------------------------------------------
    // 3. Accelerator Shell Interface (ext_act_broadcast_i/valid/ready)
    // -------------------------------------------------------------------------
    output logic [DATA_WIDTH-1:0]           act_stream_data_o,
    output logic                            act_stream_valid_o,
    input  logic                            act_stream_ready_i
);

    // =========================================================================
    // 1. TỐI GIẢN FSM & ĐIỀU KHIỂN
    // =========================================================================
    typedef enum logic [1:0] { IDLE, STREAM, FREEZE, DRAIN_WAIT } state_t;
    state_t state_q, state_d;

    logic [31:0]           k_cnt_q,      k_cnt_d;
    logic [31:0]           tok_cnt_q,    tok_cnt_d;
    logic [31:0]           freeze_cnt_q, freeze_cnt_d;
    logic [ADDR_WIDTH-1:0] addr_q,       addr_d;
    logic [DATA_WIDTH-1:0] latched_q,    latched_d;

    // Outstanding-read credit.  The AGU advances on request acceptance, so a
    // fast request stream can outrun the TCDM responses.  With a 2-entry skid
    // buffer, at most two reads may be in flight (one in the skid, one on the
    // return path); otherwise responses would be dropped.
    logic [2:0] outstanding_q, outstanding_d;

    // Bắt tay và bộ đệm Skid Buffer 2 phần tử
    logic [DATA_WIDTH-1:0] skid_data_out;
    logic [1:0]            skid_level;
    wire skid_ready;
    wire skid_valid;
    wire tcdm_fire     = m_tcdm_req_valid_o && m_tcdm_req_ready_i;
    wire core_fire     = act_stream_valid_o && act_stream_ready_i;
    wire req_counted   = tcdm_fire && (state_q == STREAM);
    wire rsp_counted   = m_tcdm_rsp_valid_i && (state_q == STREAM || state_q == DRAIN_WAIT);
    wire issue_ok      = skid_ready && ((outstanding_q + {1'b0, skid_level}) < 3'd2);

    always_comb begin
        state_d      = state_q;
        k_cnt_d      = k_cnt_q;
        tok_cnt_d    = tok_cnt_q;
        freeze_cnt_d = freeze_cnt_q;
        addr_d       = addr_q;
        latched_d    = latched_q;
        outstanding_d = outstanding_q;
        done_irq_o   = 1'b0;

        m_tcdm_req_valid_o = 1'b0;
        m_tcdm_req_write_o = 1'b0;
        m_tcdm_req_addr_o  = addr_q;
        m_tcdm_req_wdata_o = '0;
        m_tcdm_req_strb_o  = '0;

        case (state_q)
            IDLE: begin
                if (csr_start_i) begin
                    addr_d       = cfg_base_addr_i;
                    k_cnt_d      = '0;
                    tok_cnt_d    = '0;
                    freeze_cnt_d = '0;
                    state_d      = cfg_freeze_mode_i ? FREEZE : STREAM;
                end
            end

            // Chế độ 1: Normal Streaming (Prefill / GEMM)
            STREAM: begin
                m_tcdm_req_valid_o = issue_ok;
                if (tcdm_fire) begin
                    if (k_cnt_q < cfg_k_blocks_i - 1'b1) begin
                        k_cnt_d = k_cnt_q + 1'b1;
                        addr_d  = addr_q + cfg_k_stride_i;
                    end else begin
                        k_cnt_d = '0;
                        if (tok_cnt_q < cfg_tokens_i - 1'b1) begin
                            tok_cnt_d = tok_cnt_q + 1'b1;
                            addr_d    = addr_q + cfg_token_stride_i;
                        end else begin
                            state_d = DRAIN_WAIT;
                        end
                    end
                end
            end

            // Chế độ 2: Freeze Mode (Decode) - Đọc đúng 1 lần vào latched_q rồi ngắt TCDM
            FREEZE: begin
                if (freeze_cnt_q == '0) begin
                    m_tcdm_req_valid_o = 1'b1; // Fetch 1 word duy nhất
                    if (m_tcdm_rsp_valid_i) begin
                        latched_d    = m_tcdm_rsp_rdata_i;
                        freeze_cnt_d = 32'd1;
                    end
                end else if (core_fire) begin
                    // Đã chốt xong: Cổng TCDM ngắt hoàn toàn (Zero Traffic)
                    if (freeze_cnt_q < cfg_freeze_cycles_i) begin
                        freeze_cnt_d = freeze_cnt_q + 1'b1;
                    end else begin
                        done_irq_o = 1'b1;
                        state_d    = IDLE;
                    end
                end
            end

            DRAIN_WAIT: begin
                if (!skid_valid && (outstanding_q == 0)) begin
                    done_irq_o = 1'b1;
                    state_d    = IDLE;
                end
            end

            default: state_d = IDLE;
        endcase

        // Credit bookkeeping (FREEZE reads are not counted).
        if (req_counted) begin 
            outstanding_d = outstanding_d + 1'b1;
        end 
        if (rsp_counted && (outstanding_q != 0)) begin 
            outstanding_d = outstanding_d - 1'b1;
        end 
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_q      <= IDLE;
            k_cnt_q      <= '0;
            tok_cnt_q    <= '0;
            freeze_cnt_q <= '0;
            addr_q       <= '0;
            latched_q    <= '0;
            outstanding_q <= '0;
        end else begin
            state_q      <= state_d;
            k_cnt_q      <= k_cnt_d;
            tok_cnt_q    <= tok_cnt_d;
            freeze_cnt_q <= freeze_cnt_d;
            addr_q       <= addr_d;
            latched_q    <= latched_d;
            outstanding_q <= outstanding_d;
        end
    end

    // =========================================================================
    // 2. SKID BUFFER & OUTPUT MUX
    // =========================================================================
    wire skid_push = m_tcdm_rsp_valid_i && (state_q == STREAM || state_q == DRAIN_WAIT);
    wire skid_pop  = core_fire && (state_q == STREAM || state_q == DRAIN_WAIT);

    skid_buffer #(
        .DATA_WIDTH (DATA_WIDTH),
        .DEPTH      (2)
    ) u_skid_buffer (
        .clk        (clk),
        .rst_n      (rst_n),
        .push       (skid_push),
        .data_in    (m_tcdm_rsp_rdata_i),
        .pop        (skid_pop),
        .data_out   (skid_data_out),
        .ready      (skid_ready),
        .valid      (skid_valid),
        .level      (skid_level)
    );

    assign act_stream_data_o  = (state_q == FREEZE) ? latched_q : skid_data_out;
    assign act_stream_valid_o = (state_q == FREEZE) ? (freeze_cnt_q > '0) : skid_valid;

    assign busy_o = (state_q != IDLE);

endmodule
