// =============================================================================
// Module: snax_streamer_write_out.sv
// Description: Clean, High-PPA Output Write Streamer & Hardware Transposer
//              - Connects to TCDM Master Port 18
//              - Mode 0 (Linear Mode): Flattens FP4/FP16 vectors into linear RAM
//              - Mode 1 (Transpose Mode): Gathers 16 tokens into 16x16 buffer,
//                flushes column-by-column into Bank 0..15 -> Pre-formatted for V!
// =============================================================================
`timescale 1ns/1ps

module snax_streamer_write_out #(
    parameter int unsigned DATA_WIDTH = 72,   // 72-bit TCDM Word
    parameter int unsigned ADDR_WIDTH = 32,   // 32-bit Address
    parameter int unsigned NUM_LANES  = 16,   // 16 Lanes
    parameter int unsigned STRB_WIDTH = 9     // 9-bit Strobe
)(
    input  logic                            clk,
    input  logic                            rst_n,

    // -------------------------------------------------------------------------
    // 1. CSR Control & Configuration
    // -------------------------------------------------------------------------
    input  logic                            csr_start_i,
    output logic                            busy_o,
    output logic                            done_irq_o,

    input  logic                            cfg_mode_transpose_i,// 1: Xoay trục làm ma trận V; 0: Ghi phẳng
    input  logic [ADDR_WIDTH-1:0]           cfg_base_addr_i,    // Địa chỉ gốc ghi trên TCDM
    input  logic [31:0]                     cfg_num_vectors_i,  // Tổng số vectors 16-channel cần ghi
    input  logic [31:0]                     cfg_line_stride_i,  // Bước nhảy địa chỉ

    // -------------------------------------------------------------------------
    // 2. Accelerator Shell Interface
    // -------------------------------------------------------------------------
    input  logic [NUM_LANES*16-1:0]         core_out_fp16_data_i,
    input  logic                            core_out_fp16_valid_i,
    output logic                            core_out_fp16_ready_o,

    input  logic [DATA_WIDTH-1:0]           core_out_fp4_data_i,
    input  logic                            core_out_fp4_valid_i,
    output logic                            core_out_fp4_ready_o,

    // -------------------------------------------------------------------------
    // 3. TCDM Master Port 18
    // -------------------------------------------------------------------------
    output logic                            m_tcdm_req_valid_o,
    output logic                            m_tcdm_req_write_o,
    output logic [ADDR_WIDTH-1:0]           m_tcdm_req_addr_o,
    output logic [DATA_WIDTH-1:0]           m_tcdm_req_wdata_o,
    output logic [STRB_WIDTH-1:0]           m_tcdm_req_strb_o,
    input  logic                            m_tcdm_req_ready_i
);

    // =========================================================================
    // 1. TỐI GIẢN FSM
    // =========================================================================
    typedef enum logic [1:0] { IDLE, WRITE_LINEAR, TRANS_GATHER, TRANS_FLUSH } state_t;
    state_t state_q, state_d;

    logic [31:0]           vec_cnt_q,    vec_cnt_d;
    logic [ADDR_WIDTH-1:0] write_addr_q, write_addr_d;
    logic [3:0]            gather_cnt_q, gather_cnt_d;
    logic [3:0]            flush_ch_q,   flush_ch_d;
    logic [1:0]            flush_word_q, flush_word_d; // 0..3: tokens 4w..4w+3

    // Corner Turn Buffer: Mảng thanh ghi 16x16 elements (mỗi element 16-bit FP16)
    logic [15:0] corner_buf [0:15][0:15]; // [token][channel]

    wire tcdm_fire = m_tcdm_req_valid_o && m_tcdm_req_ready_i;

    always_comb begin
        state_d         = state_q;
        vec_cnt_d       = vec_cnt_q;
        write_addr_d    = write_addr_q;
        gather_cnt_d    = gather_cnt_q;
        flush_ch_d      = flush_ch_q;
        flush_word_d    = flush_word_q;
        done_irq_o      = 1'b0;

        core_out_fp16_ready_o = 1'b0;
        core_out_fp4_ready_o  = 1'b0;

        m_tcdm_req_valid_o    = 1'b0;
        m_tcdm_req_write_o    = 1'b1; // Cổng ghi
        m_tcdm_req_strb_o     = 9'h1FF;
        m_tcdm_req_addr_o     = write_addr_q;
        m_tcdm_req_wdata_o    = '0;

        case (state_q)
            IDLE: begin
                if (csr_start_i) begin
                    vec_cnt_d    = '0;
                    write_addr_d = cfg_base_addr_i;
                    gather_cnt_d = '0;
                    flush_ch_d   = '0;
                    flush_word_d = '0;
                    state_d      = cfg_mode_transpose_i ? TRANS_GATHER : WRITE_LINEAR;
                end
            end

            // Chế độ 1: Ghi phẳng tuyến tính (Linear Mode cho CPU/DMA)
            WRITE_LINEAR: begin
                core_out_fp4_ready_o = m_tcdm_req_ready_i;
                if (core_out_fp4_valid_i) begin
                    m_tcdm_req_valid_o = 1'b1;
                    m_tcdm_req_wdata_o = core_out_fp4_data_i;

                    if (tcdm_fire) begin
                        write_addr_d = write_addr_q + cfg_line_stride_i;
                        if (vec_cnt_q < cfg_num_vectors_i - 1'b1) begin
                            vec_cnt_d = vec_cnt_q + 1'b1;
                        end else begin
                            done_irq_o = 1'b1;
                            state_d    = IDLE;
                        end
                    end
                end
            end

            // Chế độ 2A: Gom đủ 16 tokens từ Core vào mảng thanh ghi
            TRANS_GATHER: begin
                core_out_fp16_ready_o = 1'b1;
                if (core_out_fp16_valid_i) begin
                    if (gather_cnt_q < 4'd15) begin
                        gather_cnt_d = gather_cnt_q + 1'b1;
                    end else begin
                        gather_cnt_d = '0;
                        flush_ch_d   = '0;
                        flush_word_d = '0;
                        state_d      = TRANS_FLUSH;
                    end
                end
            end

            // Chế độ 2B: Xả theo cột dọc xuống Bank 0..15 của TCDM (Zero-Conflict cho V)
            TRANS_FLUSH: begin
                m_tcdm_req_valid_o = 1'b1;
                // Bank = channel [8:4]; word = base word + flush_word.
                // 4 words/channel cover all 16 tokens: tokens 4w..4w+3.
                m_tcdm_req_addr_o  = {write_addr_q[31:9], flush_ch_q, 4'b0000}
                                     + (flush_word_q << 9);
                // Pack 4 FP16 values along the token direction into 64 bits.
                m_tcdm_req_wdata_o = {8'h00,
                                      corner_buf[flush_word_q*4 + 3][flush_ch_q],
                                      corner_buf[flush_word_q*4 + 2][flush_ch_q],
                                      corner_buf[flush_word_q*4 + 1][flush_ch_q],
                                      corner_buf[flush_word_q*4 + 0][flush_ch_q]};

                if (tcdm_fire) begin
                    if (flush_word_q < 2'd3) begin
                        flush_word_d = flush_word_q + 1'b1;
                    end else begin
                        flush_word_d = '0;
                        if (flush_ch_q < 4'd15) begin
                            flush_ch_d = flush_ch_q + 1'b1;
                        end else begin
                            flush_ch_d   = '0;
                            write_addr_d = write_addr_q + cfg_line_stride_i;
                            if (vec_cnt_q < cfg_num_vectors_i - 1'b1) begin
                                vec_cnt_d = vec_cnt_q + 1'b1;
                                state_d   = TRANS_GATHER;
                            end else begin
                                done_irq_o = 1'b1;
                                state_d    = IDLE;
                            end
                        end
                    end
                end
            end

            default: state_d = IDLE;
        endcase
    end

    // Sequential registers
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_q      <= IDLE;
            vec_cnt_q    <= '0;
            write_addr_q <= '0;
            gather_cnt_q <= '0;
            flush_ch_q   <= '0;
            flush_word_q <= '0;
            for (int t = 0; t < 16; t++) begin
                for (int c = 0; c < 16; c++) begin
                    corner_buf[t][c] <= 16'h0000;
                end
            end
        end else begin
            state_q      <= state_d;
            vec_cnt_q    <= vec_cnt_d;
            write_addr_q <= write_addr_d;
            gather_cnt_q <= gather_cnt_d;
            flush_ch_q   <= flush_ch_d;
            flush_word_q <= flush_word_d;

            // Ghi hàng ngang từ Core vào Buffer
            if (state_q == TRANS_GATHER && core_out_fp16_valid_i) begin
                for (int c = 0; c < 16; c++) begin
                    corner_buf[gather_cnt_q][c] <= core_out_fp16_data_i[c*16 +: 16];
                end
            end
        end
    end

    assign busy_o = (state_q != IDLE);

endmodule
