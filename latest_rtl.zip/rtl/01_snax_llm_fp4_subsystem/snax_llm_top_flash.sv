// =============================================================================
// Module: snax_llm_top_flash
// Description: Integrated SNAX FP4 FlashAttention subsystem top.
//
//   host CSR + host DMA
//        |
//   19-master interleaved xbar (0 host, 1 act, 2..17 wt, 18 out)
//        |
//   32-bank x 1024 x 72b TCDM
//        |
//   + snax_streamer_act_bcast
//   + snax_streamer_wt_16ch
//   + snax_streamer_write_out (linear FP4)
//   + skid_buffer for FP4 backpressure
//   + snax_fused_llm_core (8 queries, 8:8 slots)
//   + snax_flash_seq (hardware h->qi->dvi->kj sequencer)
//
// Host CSR map (word addresses):
//   0x000 : bit0 = start pulse
//   0x004 : bit0 = busy, bit1 = done
//   0x008 : ID/version
//
// Host DMA master 0 provides TCDM preload/readback.
// Fixed data map (same as tb_snax_core_flash_system):
//   Q  bank16, word = h*32 + q*2 + kb
//   K  bank0..15, word = h*4 + kj*2 + kb
//   V  bank0..15, word = 16 + h*4 + dvi*2 + kj
//   OUT bank17, word = 0..
// =============================================================================
`timescale 1ns/1ps
`include "pe_defines.svh"

module snax_llm_top_flash #(
    parameter int unsigned DATA_WIDTH  = 72,
    parameter int unsigned STRB_WIDTH  = 9,
    parameter int unsigned ADDR_WIDTH  = 32,
    parameter int unsigned NUM_BANKS   = 32,
    parameter int unsigned BANK_DEPTH  = 1024,
    parameter int unsigned NUM_LANES   = 16,
    parameter int unsigned ACC_DEPTH   = 16
)(
    input  logic clk,
    input  logic rst_n,

    // Host CSR
    input  logic        host_csr_we_i,
    input  logic [11:0] host_csr_addr_i,
    input  logic [31:0] host_csr_wdata_i,
    output logic [31:0] host_csr_rdata_o,

    // Host DMA / TCDM port (master 0)
    input  logic                    host_mem_req_valid_i,
    output logic                    host_mem_req_ready_o,
    input  logic [ADDR_WIDTH-1:0]   host_mem_req_addr_i,
    input  logic                    host_mem_req_write_i,
    input  logic [DATA_WIDTH-1:0]   host_mem_req_wdata_i,
    input  logic [STRB_WIDTH-1:0]   host_mem_req_strb_i,
    output logic                    host_mem_rsp_valid_o,
    output logic [DATA_WIDTH-1:0]   host_mem_rsp_rdata_o,

    // Status / debug
    output logic                    subsystem_busy_o,
    output logic                    subsystem_done_irq_o,
    output logic [NUM_LANES*16-1:0] dbg_fp16_packed_o,
    output logic                    dbg_fp16_valid_o
);

    localparam int NUM_MASTERS = 19;

    // -------------------------------------------------------------------------
    // CSR
    // -------------------------------------------------------------------------
    logic start_pulse;
    logic csr_we_start;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) start_pulse <= 1'b0;
        else begin
            start_pulse <= 1'b0;
            if (host_csr_we_i && (host_csr_addr_i == 12'h000) &&
                host_csr_wdata_i[0])
                start_pulse <= 1'b1;
        end
    end

    always_comb begin
        case (host_csr_addr_i)
            12'h000: host_csr_rdata_o = {31'd0, start_pulse};
            12'h004: host_csr_rdata_o = {30'd0, subsystem_done_irq_o,
                                         subsystem_busy_o};
            12'h008: host_csr_rdata_o = 32'h534E_4146; // "SNAF"
            default: host_csr_rdata_o = 32'd0;
        endcase
    end

    // -------------------------------------------------------------------------
    // Interconnect
    // -------------------------------------------------------------------------
    logic [NUM_MASTERS-1:0]          m_req_valid;
    logic [NUM_MASTERS-1:0]          m_req_ready;
    logic [NUM_MASTERS-1:0][31:0]    m_req_addr;
    logic [NUM_MASTERS-1:0]          m_req_write;
    logic [NUM_MASTERS-1:0][71:0]    m_req_wdata;
    logic [NUM_MASTERS-1:0][8:0]     m_req_strb;
    logic [NUM_MASTERS-1:0]          m_rsp_valid;
    logic [NUM_MASTERS-1:0][71:0]    m_rsp_rdata;

    logic [NUM_BANKS-1:0]         b_req;
    logic [NUM_BANKS-1:0]         b_write;
    logic [NUM_BANKS-1:0][9:0]    b_addr;
    logic [NUM_BANKS-1:0][71:0]   b_wdata;
    logic [NUM_BANKS-1:0][8:0]    b_strb;
    logic [NUM_BANKS-1:0][71:0]   b_rdata;
    logic [NUM_BANKS-1:0]         b_rvalid;

    // -------------------------------------------------------------------------
    // Streamers
    // -------------------------------------------------------------------------
    logic act_start, act_busy, act_freeze;
    logic [31:0] act_base, act_k_blocks, act_k_stride, act_tokens, act_token_stride;
    logic act_m_req_valid, act_m_req_write, act_m_req_ready;
    logic [31:0] act_m_req_addr;
    logic [71:0] act_m_req_wdata;
    logic [8:0]  act_m_req_strb;
    logic [71:0] act_m_rsp_rdata;
    logic        act_m_rsp_valid;
    logic [71:0] act_stream_data;
    logic        act_stream_valid, act_stream_ready;

    logic wt_start, wt_busy;
    logic [31:0] wt_base, wt_repeat, wt_k_blocks, wt_k_stride, wt_num_tiles, wt_tile_step;
    logic [15:0] wt_m_req_valid, wt_m_req_write, wt_m_req_ready;
    logic [15:0][31:0] wt_m_req_addr;
    logic [15:0][71:0] wt_m_req_wdata;
    logic [15:0][8:0]  wt_m_req_strb;
    logic [15:0][71:0] wt_m_rsp_rdata;
    logic [15:0]       wt_m_rsp_valid;
    logic [15:0][71:0] wt_stream_data;
    logic [15:0]       wt_stream_valid, wt_stream_ready;

    logic wo_start, wo_busy, wo_transpose;
    logic [31:0] wo_base, wo_num_vectors, wo_line_stride;
    logic wo_m_req_valid, wo_m_req_write, wo_m_req_ready;
    logic [31:0] wo_m_req_addr;
    logic [71:0] wo_m_req_wdata;
    logic [8:0]  wo_m_req_strb;

    logic [255:0] core_fp16_packed;
    logic         core_fp16_valid;
    logic [71:0]  core_fp4_packet;
    logic         core_fp4_valid;
    logic         wo_fp16_ready, wo_fp4_ready;
    logic [71:0]  wo_fp4_data;

    logic        fp4_skid_push, fp4_skid_pop;
    logic [71:0] fp4_skid_din, fp4_skid_dout;
    logic        fp4_skid_ready, fp4_skid_valid;
    logic [4:0]  fp4_skid_level;

    // -------------------------------------------------------------------------
    // Core control from sequencer
    // -------------------------------------------------------------------------
    logic [1:0]  cfg_mode;
    logic        cfg_row_start;
    logic [15:0] cfg_key_mask;
    logic        cfg_enable_slq;
    logic        tile_drain_req;
    logic [3:0]  tile_drain_idx;
    logic        tile_clear_on_drain;
    logic [15:0] lane_valid;
    logic [3:0]  lane_acc_idx;
    logic        p_fifo_full, p_fifo_empty, p_fifo_almost_full, l_ready;
    logic        seq_busy, seq_done;

    assign subsystem_busy_o     = seq_busy;
    assign subsystem_done_irq_o = seq_done;
    assign dbg_fp16_packed_o    = core_fp16_packed;
    assign dbg_fp16_valid_o     = core_fp16_valid;

    // -------------------------------------------------------------------------
    // Host master 0
    // -------------------------------------------------------------------------
    assign m_req_valid[0]  = host_mem_req_valid_i;
    assign m_req_addr[0]   = host_mem_req_addr_i;
    assign m_req_write[0]  = host_mem_req_write_i;
    assign m_req_wdata[0]  = host_mem_req_wdata_i;
    assign m_req_strb[0]   = host_mem_req_strb_i;
    assign host_mem_req_ready_o = m_req_ready[0];
    assign host_mem_rsp_valid_o = m_rsp_valid[0];
    assign host_mem_rsp_rdata_o = m_rsp_rdata[0];

    // Act master 1
    assign m_req_valid[1]  = act_m_req_valid;
    assign m_req_addr[1]   = act_m_req_addr;
    assign m_req_write[1]  = act_m_req_write;
    assign m_req_wdata[1]  = act_m_req_wdata;
    assign m_req_strb[1]   = act_m_req_strb;
    assign act_m_req_ready = m_req_ready[1];
    assign act_m_rsp_valid = m_rsp_valid[1];
    assign act_m_rsp_rdata = m_rsp_rdata[1];

    // Wt masters 2..17
    genvar gw;
    generate
        for (gw = 0; gw < 16; gw++) begin : GEN_WT
            assign m_req_valid[2+gw]  = wt_m_req_valid[gw];
            assign m_req_addr[2+gw]   = wt_m_req_addr[gw];
            assign m_req_write[2+gw]  = wt_m_req_write[gw];
            assign m_req_wdata[2+gw]  = wt_m_req_wdata[gw];
            assign m_req_strb[2+gw]   = wt_m_req_strb[gw];
            assign wt_m_req_ready[gw] = m_req_ready[2+gw];
            assign wt_m_rsp_valid[gw] = m_rsp_valid[2+gw];
            assign wt_m_rsp_rdata[gw] = m_rsp_rdata[2+gw];
        end
    endgenerate

    // Output master 18
    assign m_req_valid[18] = wo_m_req_valid;
    assign m_req_addr[18]  = wo_m_req_addr;
    assign m_req_write[18] = wo_m_req_write;
    assign m_req_wdata[18] = wo_m_req_wdata;
    assign m_req_strb[18]  = wo_m_req_strb;
    assign wo_m_req_ready  = m_req_ready[18];

    // -------------------------------------------------------------------------
    // Streamers
    // -------------------------------------------------------------------------
    snax_streamer_act_bcast #(
        .DATA_WIDTH (72), .ADDR_WIDTH (32), .STRB_WIDTH (9)
    ) u_act_streamer (
        .clk                     (clk),
        .rst_n                   (rst_n),
        .csr_start_i             (act_start),
        .busy_o                  (act_busy),
        .done_irq_o              (),
        .cfg_freeze_mode_i       (act_freeze),
        .cfg_freeze_cycles_i     (32'd0),
        .cfg_base_addr_i         (act_base),
        .cfg_k_blocks_i          (act_k_blocks),
        .cfg_k_stride_i          (act_k_stride),
        .cfg_tokens_i            (act_tokens),
        .cfg_token_stride_i      (act_token_stride),
        .m_tcdm_req_valid_o      (act_m_req_valid),
        .m_tcdm_req_write_o      (act_m_req_write),
        .m_tcdm_req_addr_o       (act_m_req_addr),
        .m_tcdm_req_wdata_o      (act_m_req_wdata),
        .m_tcdm_req_strb_o       (act_m_req_strb),
        .m_tcdm_req_ready_i      (act_m_req_ready),
        .m_tcdm_rsp_rdata_i      (act_m_rsp_rdata),
        .m_tcdm_rsp_valid_i      (act_m_rsp_valid),
        .act_stream_data_o       (act_stream_data),
        .act_stream_valid_o      (act_stream_valid),
        .act_stream_ready_i      (act_stream_ready)
    );

    snax_streamer_wt_16ch #(
        .DATA_WIDTH (72), .ADDR_WIDTH (32), .NUM_LANES (16), .STRB_WIDTH (9)
    ) u_wt_streamer (
        .clk                   (clk),
        .rst_n                 (rst_n),
        .csr_start_i           (wt_start),
        .busy_o                (wt_busy),
        .done_irq_o            (),
        .cfg_base_addr_i       (wt_base),
        .cfg_repeat_tokens_i   (wt_repeat),
        .cfg_k_blocks_i        (wt_k_blocks),
        .cfg_k_stride_i        (wt_k_stride),
        .cfg_num_tiles_i       (wt_num_tiles),
        .cfg_tile_step_i       (wt_tile_step),
        .m_tcdm_req_valid_o    (wt_m_req_valid),
        .m_tcdm_req_write_o    (wt_m_req_write),
        .m_tcdm_req_addr_o     (wt_m_req_addr),
        .m_tcdm_req_wdata_o    (wt_m_req_wdata),
        .m_tcdm_req_strb_o     (wt_m_req_strb),
        .m_tcdm_req_ready_i    (wt_m_req_ready),
        .m_tcdm_rsp_rdata_i    (wt_m_rsp_rdata),
        .m_tcdm_rsp_valid_i    (wt_m_rsp_valid),
        .wt_stream_data_o      (wt_stream_data),
        .wt_stream_valid_o     (wt_stream_valid),
        .wt_stream_ready_i     (wt_stream_ready)
    );

    snax_streamer_write_out #(
        .DATA_WIDTH (72), .ADDR_WIDTH (32), .NUM_LANES (16), .STRB_WIDTH (9)
    ) u_write_out (
        .clk                    (clk),
        .rst_n                  (rst_n),
        .csr_start_i            (wo_start),
        .busy_o                 (wo_busy),
        .done_irq_o             (),
        .cfg_mode_transpose_i   (wo_transpose),
        .cfg_base_addr_i        (wo_base),
        .cfg_num_vectors_i      (wo_num_vectors),
        .cfg_line_stride_i      (wo_line_stride),
        .core_out_fp16_data_i   (core_fp16_packed),
        .core_out_fp16_valid_i  (core_fp16_valid),
        .core_out_fp16_ready_o  (wo_fp16_ready),
        .core_out_fp4_data_i    (wo_fp4_data),
        .core_out_fp4_valid_i   (fp4_skid_valid),
        .core_out_fp4_ready_o   (wo_fp4_ready),
        .m_tcdm_req_valid_o     (wo_m_req_valid),
        .m_tcdm_req_write_o     (wo_m_req_write),
        .m_tcdm_req_addr_o      (wo_m_req_addr),
        .m_tcdm_req_wdata_o     (wo_m_req_wdata),
        .m_tcdm_req_strb_o      (wo_m_req_strb),
        .m_tcdm_req_ready_i     (wo_m_req_ready)
    );

    skid_buffer #(.DATA_WIDTH (72), .DEPTH (16)) u_fp4_skid (
        .clk      (clk),
        .rst_n    (rst_n),
        .push     (core_fp4_valid),
        .data_in  (core_fp4_packet),
        .pop      (fp4_skid_pop),
        .data_out (fp4_skid_dout),
        .ready    (fp4_skid_ready),
        .valid    (fp4_skid_valid),
        .level    (fp4_skid_level)
    );
    assign fp4_skid_pop = wo_fp4_ready;
    assign wo_fp4_data  = fp4_skid_dout;

    // -------------------------------------------------------------------------
    // Core
    // -------------------------------------------------------------------------
    snax_fused_llm_core #(
        .NUM_LANES_P  (16),
        .ACC_DEPTH_P  (ACC_DEPTH),
        .NUM_QUERIES  (8),
        .PKT_W        (72),
        .FRAC_BITS    (16),
        .P_FIFO_DEPTH (16)
    ) u_core (
        .clk                   (clk),
        .rst_n                 (rst_n),
        .cfg_mode_i            (cfg_mode),
        .cfg_row_start_i       (cfg_row_start),
        .cfg_key_mask_i        (cfg_key_mask),
        .cfg_enable_slq_i      (cfg_enable_slq),
        .tile_drain_req_i      (tile_drain_req),
        .tile_drain_idx_i      (tile_drain_idx),
        .tile_clear_on_drain_i (tile_clear_on_drain),
        .lane_valid_i          (lane_valid),
        .lane_acc_idx_i        (lane_acc_idx),
        .ext_act_broadcast_i   (act_stream_data),
        .ext_act_valid_i       (act_stream_valid),
        .wt_in_i               (wt_stream_data),
        .wt_valid_i            (&wt_stream_valid),
        .out_vec_fp16_packed_o (core_fp16_packed),
        .out_vec_fp16_lanes_o  (),
        .out_vec_fp16_valid_o  (core_fp16_valid),
        .out_vec_fp4_packet_o  (core_fp4_packet),
        .out_vec_fp4_valid_o   (core_fp4_valid),
        .p_fifo_full_o         (p_fifo_full),
        .p_fifo_empty_o        (p_fifo_empty),
        .p_fifo_almost_full_o  (p_fifo_almost_full),
        .l_ready_o             (l_ready)
    );

    // -------------------------------------------------------------------------
    // Sequencer
    // -------------------------------------------------------------------------
    snax_flash_seq #(
        .H (2), .N_Q (16), .M_Q (8), .D_K (32), .D_V (32), .KV_TILES (2)
    ) u_seq (
        .clk                (clk),
        .rst_n              (rst_n),
        .start_i            (start_pulse),
        .busy_o             (seq_busy),
        .done_o             (seq_done),
        .act_start_o        (act_start),
        .act_freeze_o       (act_freeze),
        .act_base_o         (act_base),
        .act_k_blocks_o     (act_k_blocks),
        .act_k_stride_o     (act_k_stride),
        .act_tokens_o       (act_tokens),
        .act_token_stride_o (act_token_stride),
        .act_busy_i         (act_busy),
        .act_valid_i        (act_stream_valid),
        .act_ready_o        (act_stream_ready),
        .wt_start_o         (wt_start),
        .wt_base_o          (wt_base),
        .wt_repeat_o        (wt_repeat),
        .wt_k_blocks_o      (wt_k_blocks),
        .wt_k_stride_o      (wt_k_stride),
        .wt_num_tiles_o     (wt_num_tiles),
        .wt_tile_step_o     (wt_tile_step),
        .wt_busy_i          (wt_busy),
        .wt_valid_i         (wt_stream_valid),
        .wt_ready_o         (wt_stream_ready),
        .cfg_mode_o         (cfg_mode),
        .cfg_row_start_o    (cfg_row_start),
        .cfg_key_mask_o     (cfg_key_mask),
        .cfg_enable_slq_o   (cfg_enable_slq),
        .tile_drain_req_o   (tile_drain_req),
        .tile_drain_idx_o   (tile_drain_idx),
        .tile_clear_on_drain_o (tile_clear_on_drain),
        .lane_valid_o       (lane_valid),
        .lane_acc_idx_o     (lane_acc_idx),
        .p_fifo_empty_i     (p_fifo_empty),
        .core_fp16_valid_i  (core_fp16_valid),
        .wo_start_o         (wo_start),
        .wo_transpose_o     (wo_transpose),
        .wo_base_o          (wo_base),
        .wo_num_vectors_o   (wo_num_vectors),
        .wo_line_stride_o   (wo_line_stride)
    );

    // -------------------------------------------------------------------------
    // TCDM + interconnect
    // -------------------------------------------------------------------------
    multi_bank_tcdm_72b #(
        .NUM_BANKS  (NUM_BANKS),
        .DATA_WIDTH (DATA_WIDTH),
        .STRB_WIDTH (STRB_WIDTH),
        .BANK_DEPTH (BANK_DEPTH)
    ) u_tcdm (
        .clk          (clk),
        .rst_n        (rst_n),
        .bank_req_i   (b_req),
        .bank_write_i (b_write),
        .bank_addr_i  (b_addr),
        .bank_wdata_i (b_wdata),
        .bank_strb_i  (b_strb),
        .bank_rdata_o (b_rdata),
        .bank_rvalid_o(b_rvalid)
    );

    interleaved_interconnect_72b #(
        .NUM_MASTERS (NUM_MASTERS),
        .NUM_BANKS   (NUM_BANKS),
        .DATA_WIDTH  (DATA_WIDTH),
        .ADDR_WIDTH  (ADDR_WIDTH),
        .BANK_DEPTH  (BANK_DEPTH)
    ) u_xbar (
        .clk           (clk),
        .rst_n         (rst_n),
        .m_req_valid_i (m_req_valid),
        .m_req_ready_o (m_req_ready),
        .m_req_addr_i  (m_req_addr),
        .m_req_write_i (m_req_write),
        .m_req_wdata_i (m_req_wdata),
        .m_req_strb_i  (m_req_strb),
        .m_rsp_valid_o (m_rsp_valid),
        .m_rsp_rdata_o (m_rsp_rdata),
        .b_req_o       (b_req),
        .b_write_o     (b_write),
        .b_addr_o      (b_addr),
        .b_wdata_o     (b_wdata),
        .b_strb_o      (b_strb),
        .b_rdata_i     (b_rdata),
        .b_rvalid_i    (b_rvalid)
    );

endmodule
