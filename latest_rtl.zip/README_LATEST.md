# SNAX FP4 LLM Subsystem — Latest RTL

Package date: 2026-11-09
RTL directory: `rtl/01_snax_llm_fp4_subsystem/`

## Top-level

- **`snax_llm_top_flash.sv`** — integrated top:
  - 32-bank TCDM, 19-master interleaved interconnect
  - `snax_streamer_act_bcast` + `snax_streamer_wt_16ch`
  - `snax_streamer_write_out` + FP4 skid buffer
  - `snax_fused_llm_core` (8 queries, 8:8 slots)
  - `snax_flash_seq` hardware flash-tiling sequencer
  - host CSR (`0x000` start, `0x004` {done,busy}, `0x008` ID)
  - host DMA master 0 for TCDM preload/readback
- `snax_llm_top.sv` / `snax_llm_shell.sv` are the older scaffold and are kept
  for reference; they are **not** used by the integrated top.

## New / important files

| File | Note |
|---|---|
| `snax_llm_top_flash.sv` | integrated top |
| `snax_flash_seq.sv` | h -> qi -> dvi -> kj sequencer |
| `snax_streamer_act_bcast.sv` | act/Q streamer, outstanding-read credit fix |
| `snax_streamer_wt_16ch.sv` | 16-lane K/V/W streamer, real TCDM base address |
| `snax_streamer_write_out.sv` | output streamer, transpose flush 4 words/channel |
| `skid_buffer.sv` | reusable elastic FIFO |
| `fixed_priority_arb_n.sv` | per-bank fixed-priority arbiter |
| `interleaved_interconnect_72b.sv` | uses fixed-priority arbiter |
| `compressor_4to2.sv` | 4:2 carry-save compressor |
| `latch_array.sv` | real latch array (synthesis) |

## Simulation-only model

`sim/latch_array_sim.sv` is a cycle-equivalent behavioral replacement for
`latch_array.sv` (avoids flattening 8192 D-latches in Verilator). It is **not**
synthesizable. Use it only for simulation; use `rtl/.../latch_array.sv` for
synthesis.

## Fixed data map used by the integrated top

```
Q   : bank 16, word = h*32 + q*2 + kb
K   : bank 0..15, word = h*4 + kj*2 + kb
V   : bank 0..15, word = 16 + h*4 + dvi*2 + kj
OUT : bank 17, word = 0..
```

`cfg_base_addr_i` of `snax_streamer_wt_16ch` is the **real TCDM byte address
of lane 0** (16-byte aligned); lane `w` is at `base + w*16`.

## Arbiter priority

Per-bank fixed priority:
`act(1) > wt(2..17) > out(18) > host/DMA(0)`.
A stream engine always wins over host/DMA on the same bank; host/DMA must
tolerate `ready` being low. Strict priority can starve the host if a streamer
continuously requests the same bank; use disjoint banks / double buffering if
host progress is required.

## Compile / lint

From the package root:

```bash
verilator --lint-only --timing \
  --top-module snax_llm_top_flash \
  -Irtl/01_snax_llm_fp4_subsystem \
  -f filelist_top_flash_sim.f
```

For a full simulation, add a testbench as the top and use the same RTL list;
`filelist_top_flash_sim.f` includes `sim/latch_array_sim.sv` instead of the
real latch array. `filelist_top_flash_rtl.f` is the synthesis/RTL list.

## Verification status

- `tb_snax_core_flash_tiling`: PASS 1024/1024 bit-exact
- `tb_snax_core_flash_system`: PASS 1024/1024 bit-exact
- `tb_snax_llm_top_flash`: PASS 1024/1024 bit-exact
- `tb_snax_streamer_write_out` transpose: PASS 256/256
- `tb_snax_streamer_wt_16ch`: PASS
- `tb_fixed_priority_arb`: PASS

## Known remaining items

- The integrated top is pattern-specific: dimensions are compile-time
  parameters in `snax_flash_seq`; CSR exposes only start/status.
- Top output path uses linear FP4; transpose mode is fixed and unit-tested
  separately.
- The old 4 TBs (prefill/tiled/attention/8x8) have not been re-run with this
  exact RTL snapshot.
- No synthesis/timing run with the real latch array yet.
